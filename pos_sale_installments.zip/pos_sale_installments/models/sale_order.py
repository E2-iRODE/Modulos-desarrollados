import logging
from odoo import models, fields, api, Command

_logger = logging.getLogger(__name__)

INSTALLMENT_FEE_CATEGORY = 'Cuotas'


class SaleOrderInstallmentTerm(models.Model):
    _inherit = 'sale.order'

    installment_term_id = fields.Many2one(
        comodel_name='pos.payment.installment.term',
        string='Plan de cuotas',
        ondelete='set null',
        help='Al seleccionar un plan, se calculará automáticamente el recargo.'
    )
    installment_count = fields.Integer(
        string='Número de cuotas',
        compute='_compute_installment_info',
        store=False,
    )
    installment_surcharge = fields.Float(
        string='Recargo (%)',
        compute='_compute_installment_info',
        store=False,
        digits=(16, 2),
    )
    installment_name = fields.Char(
        string='Nombre del plan de cuotas',
        compute='_compute_installment_info',
        store=False,
    )

    payment_method_id = fields.Many2one(
        'pos.payment.method',
        string='Método de pago POS'
    )

    @api.depends('installment_term_id')
    def _compute_installment_info(self):
        for order in self:
            if order.installment_term_id:
                order.installment_count = order.installment_term_id.installments or 0
                order.installment_surcharge = order.installment_term_id.surcharge_percent or 0.0
                order.installment_name = order.installment_term_id.payment_method_id.name
            else:
                order.installment_count = 0
                order.installment_surcharge = 0.0
                order.installment_name = ''

    @api.onchange('installment_term_id', 'order_line')
    def _onchange_installment_term_update_fee(self):
        for order in self:
           
            fee_lines = []
            normal_lines = []
            
            for line in order.order_line:
                if _is_fee_line(line):
                    fee_lines.append(line)
                elif not line.display_type:
                    normal_lines.append(line)

            surcharge_pct = order.installment_term_id.surcharge_percent or 0.0

            
            if not order.installment_term_id or surcharge_pct <= 0:
                if fee_lines:
                    
                    order.order_line = [Command.unlink(l.id) if l.id else Command.delete(l.id) for l in fee_lines]
                continue

         
            base = sum(l.price_subtotal for l in normal_lines)
            fee_amount = round(base * surcharge_pct / 100.0, 2)

      
            fee_product = self.env['product.product'].search([
                ('categ_id.name', '=', INSTALLMENT_FEE_CATEGORY)
            ], limit=1)

            if not fee_product:
                _logger.warning("No se encontró ningún producto en la categoría '%s' para aplicar el recargo.", INSTALLMENT_FEE_CATEGORY)
                continue

            
            if fee_lines:
                
                fee_lines[0].price_unit = fee_amount
                fee_lines[0].name = f"Recargo por pago en cuotas ({surcharge_pct}%)"
                
                
                if len(fee_lines) > 1:
                    lines_to_remove = fee_lines[1:]
                    order.order_line = [Command.unlink(l.id) if l.id else Command.delete(l.id) for l in lines_to_remove]
            else:
                
                new_line_vals = {
                    'product_id': fee_product.id,
                    'name': f"Recargo por pago en cuotas ({surcharge_pct}%)",
                    'product_uom_qty': 1,
                    'price_unit': fee_amount,
                    
                }
                order.order_line = [Command.create(new_line_vals)]


def _is_fee_line(line):
    """
    True si el producto de la linea pertenece a la categoria 'Cuotas'
    o a cualquier subcategoria de ella.
    """
    try:
        if not line or not line.product_id or line.display_type:
            return False

        categ = line.product_id.categ_id
        visited = set()
        while categ and categ.id and categ.id not in visited:
            visited.add(categ.id)
            if (categ.name or '').strip() == INSTALLMENT_FEE_CATEGORY:
                return True
            categ = categ.parent_id

        return False
    except Exception as e:
        _logger.warning('Error en _is_fee_line: %s', e)
        return False