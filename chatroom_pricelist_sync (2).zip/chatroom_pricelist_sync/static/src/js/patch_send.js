odoo.define(
  "chatroom_pricelist_sync.patch_send",
  [
    "@web/core/utils/patch",
    "@e71c685495b3fd5a77d050fe9a0ee4564da20c118bd360ce54260886e1bb13ef",
    "chatroom_pricelist_sync.patch_product_container",
  ],
  function (require) {
    "use strict";

    const { patch } = require("@web/core/utils/patch");
    const bundle = require("@e71c685495b3fd5a77d050fe9a0ee4564da20c118bd360ce54260886e1bb13ef");
    const ProductContainer = require("chatroom_pricelist_sync.patch_product_container");
    const ConversationModel = bundle && bundle.ConversationModel;
    const ERR = (...a) => console.error("[chatroom_pricelist_sync]", ...a);

    if (!ConversationModel) {
      ERR("ConversationModel NOT FOUND");
      return;
    }

    patch(ConversationModel.prototype, {
      async messageSeen() {
        await super.messageSeen();

        if (this.env && this.env.bus) {
          this.env.bus.trigger("searchProducto", {});
        }
      },
    });
  },
);
