odoo.define(
  "chatroom_pricelist_sync.patch_product_container",
  [
    "@web/core/utils/patch",
    "@aedb85b64f8970ed4ccdcfb5fad7484eb5f9502792073b672b574c2d95ef5fe2",
  ],
  function (require) {
    "use strict";

    const { patch } = require("@web/core/utils/patch");
    const bundle = require("@aedb85b64f8970ed4ccdcfb5fad7484eb5f9502792073b672b574c2d95ef5fe2");
    const ProductContainer = bundle && bundle.ProductContainer;
    const ERR = (...a) => console.error("[chatroom_pricelist_sync]", ...a);
    const WARN = (...a) => console.warn("[chatroom_pricelist_sync]", ...a);

    if (!ProductContainer) {
      ERR("ProductContainer NOT FOUND");
      return;
    }

    patch(ProductContainer.prototype, {
      setup() {
        super.setup?.(...arguments);

        if (this.env && this.env.bus) {
          this.env.bus.addEventListener(
            "searchProducto",
            this._onTriggerProductSearch.bind(this),
          );
        }
      },

      async _onTriggerProductSearch() {
        try {
          await this.searchProduct();
        } catch (error) {
          WARN("None");
        }
      },

      async searchProduct() {
        await super.searchProduct?.();

        const conv = this.props?.selectedConversation;

        const partnerId = conv?.partner?.id || null;
        const partnerName =
          conv?.partner?.name ||
          conv?.partner?.display_name ||
          conv?.partner?.label ||
          "N/A";

        if (!partnerId) {
          console.warn("No partner found, skipping custom search logic.");
          return; // Salimos de la función si no hay partner
        }

        const products = this.state?.products || [];

        // 2) leer partner + comercial + pricelist
        let partner;
        try {
          [partner] = await this.env.services.orm.read(
            "res.partner",
            [partnerId],
            [
              "display_name",
              "parent_id",
              "commercial_partner_id",
              "property_product_pricelist",
            ],
            { context: this.env.context },
          );
        } catch (e) {
          ERR("read(res.partner) failed:", e);
          return;
        }

        const commercialId = partner?.commercial_partner_id?.[0] || partnerId;
        let pricelistId = partner?.property_product_pricelist?.[0] || null;
        let pricelistName = partner?.property_product_pricelist?.[1] || null;

        // 4) RPC precios
        const productIds = products.map((p) => p.id);
        let prices;
        try {
          prices = await this.env.services.orm.call(
            "product.product",
            "chatroom_get_prices",
            [productIds, pricelistId, commercialId, 1.0],
            { context: this.env.context },
          );
        } catch (e) {
          ERR("RPC chatroom_get_prices failed:", e);
          return;
        }

        // 5) analítica del dict retornado
        const keys = Object.keys(prices || {});

        // 6) comparar 10 productos
        const sample = products.slice(0, 10).map((p) => ({
          id: p.id,
          name: p.name,
          old_lstPrice: p.lstPrice,
          old_price: p.price,
          old_display_price: p.display_price,
          new_rpc: prices ? prices[p.id] : undefined,
        }));

        // 7) aplicar cambios (escribimos en varios campos por compatibilidad)
        let changed = 0;
        for (const p of products) {
          const newPrice = prices ? prices[p.id] : undefined;

          if (newPrice === undefined || newPrice === null) continue;

          // Si no cambia, saltar
          if (
            p.lstPrice === newPrice &&
            p.price === newPrice &&
            p.display_price === newPrice
          )
            continue;

          // Campos típicos vistos en catálogos OWL
          p.basePrice = newPrice;
          p.lstPrice = newPrice;
          p.price = newPrice;
          p.display_price = newPrice;
          // algunos módulos usan list_price/lst_price en el JSON
          p.list_price = newPrice;
          p.lst_price = newPrice;

          changed += 1;
        }
      },
    });
  },
);
