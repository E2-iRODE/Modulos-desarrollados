odoo.define(
  "chatroom_pricelist_sync.patch_product_model",
  [
    "@web/core/utils/patch",
    "@a57f7a72eb29be2e68a9675edd680394d67e2ecd8df85dc2c38e83822c8551e8",
  ],
  function (require) {
    "use strict";

    const { patch } = require("@web/core/utils/patch");
    const bundle = require("@a57f7a72eb29be2e68a9675edd680394d67e2ecd8df85dc2c38e83822c8551e8");

    const ProductModel = bundle && bundle.ProductModel;
    const ERR = (...a) => console.error("[chatroom_pricelist_sync]", ...a);

    if (!ProductModel) {
      ERR("ProductModelNOT FOUND");
      return;
    }

    patch(ProductModel.prototype, {
      updateFromJson(data) {
        super.updateFromJson(data);

        this.basePrice = 9.0;
      },
    });
  },
);
