from odoo import api, fields, models
import logging

_logger = logging.getLogger(__name__)


class ProductProduct(models.Model):
    _inherit = "product.product"

    @api.model
    def chatroom_get_prices(self, product_ids, pricelist_id, partner_id=False, qty=1.0):

        products = self.browse(product_ids).exists() #Buscamos si existen los productos

        if not products:#Retornamos una lista vacia si no hay productos
            return {}


        #verificamos si el partner_id existe
        partner = self.env["res.partner"].browse(partner_id).exists() if partner_id else self.env["res.partner"]
       
       #si hay partner le asociamos el commercial_partner_id para asociemos la lista de precios segun su empresa
        partner = partner.commercial_partner_id if partner else partner

        #si el partner existe y el partner tiene una price_list asociada
        if partner and partner.property_product_pricelist:

            pricelist = partner.property_product_pricelist
        else:
            pricelist = self.env["product.pricelist"].browse(pricelist_id).exists()

        if not pricelist:
            return {}

        #
        company = pricelist.company_id or self.env.company
        today = fields.Date.context_today(self)

        #aplicamos el contexto para asegurarnos de trabajar con la compania correcta
        ctx = dict(self.env.context or {})
        ctx.update({
            "allowed_company_ids": [company.id],
            "force_company": company.id,
            "pricelist": pricelist.id,
            "currency_id": pricelist.currency_id.id, 
            "date": today,
        })
        #asignamos productos y lista de precios segun contexto
        products = products.with_company(company).with_context(ctx)
        pricelist = pricelist.with_company(company).with_context(ctx)
        
        Item = self.env["product.pricelist.item"].with_company(company).with_context(ctx)
        

        #reglas de busqueda
        def _best_item_for_product(p):
            """Retorna el pricelist.item más específico (variant > tmpl > categ > global) que aplique hoy."""
            common = [
                ("pricelist_id", "=", pricelist.id),
                "|", ("company_id", "=", False), ("company_id", "=", company.id),
                "|", ("date_start", "=", False), ("date_start", "<=", today),
                "|", ("date_end", "=", False), ("date_end", ">=", today),
            ]

            # 1) Variant
            item = Item.search(common + [
                ("applied_on", "=", "0_product_variant"),
                ("product_id", "=", p.id),
            ], order="min_quantity asc, id asc", limit=1)
            if item:
                return item

            # 2) Template
            item = Item.search(common + [
                ("applied_on", "=", "1_product"),
                ("product_tmpl_id", "=", p.product_tmpl_id.id),
            ], order="min_quantity asc, id asc", limit=1)
            if item:
                return item

            # 3) Category
            item = Item.search(common + [
                ("applied_on", "=", "2_product_category"),
                ("categ_id", "parent_of", p.categ_id.id),
            ], order="min_quantity asc, id asc", limit=1)
            if item:
                return item

            # 4) Global
            item = Item.search(common + [
                ("applied_on", "=", "3_global"),
            ], order="min_quantity asc, id asc", limit=1)
            return item

        
        try:
            result = {}
            for p in products:
                #buscamos el item
                item = _best_item_for_product(p)

                #accedemos a la cantidad minima configuradad de precios
                cand_qty = float(item.min_quantity or 1.0) if item else 1.0
                #nos asiguramos que la cand_1ty sea mayor a 1 o le asignamos 1
                qty_to_use = cand_qty if cand_qty > 1.0 else 1.0

                
                try:
                    #Este método toma todas las reglas de la lista de precios
                    price = pricelist._get_product_price(p, qty_to_use, partner=partner)
                    
                    if not price and price != 0.0:
                     
                        price = p.currency_id._convert(
                            p.lst_price, 
                            pricelist.currency_id, 
                            company, 
                            today)
                        
                #asignamos precio a producto
                    result[p.id] = price

                except Exception as e:
                  
                    result[p.id] = p.currency_id._convert(
                        p.lst_price, 
                        pricelist.currency_id, 
                        company, 
                        today
                    )

            return result

     
        except Exception as e:
            _logger.exception("[chatroom_pricelist_sync] pricelist compute failed: %s", e)
            return {p.id: p.lst_price for p in products}
