# -*- coding: utf-8 -*-
from odoo import models
from odoo.tools.safe_eval import safe_eval
from odoo.tools import formatLang


class AcruxChatConversation(models.Model):
    _inherit = "acrux.chat.conversation"

    def get_product_caption(self, product_id):
        """
        Patch mínimo:
        - Mantiene el caption original del conector (connector.product_caption)
        - Solo cambia el helper format_price() para que use el precio por pricelist del partner
        """
        self.ensure_one()

        

        # Si no hay producto o no hay partner, no inventamos nada
        if not product_id or not self.res_partner_id:
            return super().get_product_caption(product_id)

        partner = self.res_partner_id.commercial_partner_id or self.res_partner_id
        pricelist = partner.property_product_pricelist
        if not pricelist:
            return super().get_product_caption(product_id)

        # ⚡ Precio por pricelist usando TU método (ya funciona para fardo también)
        price_map = self.env["product.product"].chatroom_get_prices(
            [product_id.id], pricelist.id, partner.id, 1.0
        )
        pl_price = price_map.get(product_id.id)

        # Si por alguna razón no devolvió nada, caemos al comportamiento estándar
        if pl_price is None:
            return super().get_product_caption(product_id)

        caption = (self.connector_id.product_caption or "").strip()
        if not caption:
            # fallback mínimo si el caption está vacío
            return f"{product_id.display_name}\n{formatLang(self.env, pl_price, currency_obj=pricelist.currency_id)} / Unid"

        # 🔥 Clave: format_price ignora el argumento y devuelve el precio por pricelist
        def format_price(_ignored=None):
            return formatLang(self.env, pl_price, currency_obj=pricelist.currency_id)

        local_dict = {
            "env": self.env,
            "product_id": product_id,
            "conversation_id": self,
            "partner_id": partner,
            "pricelist_id": pricelist,
            "format_price": format_price,  # <-- inyección sin cambiar el caption original
            "text": "",
        }

        safe_eval(caption, locals_dict=local_dict, mode="exec", nocopy=True)
        return (local_dict.get("text") or "").strip()
