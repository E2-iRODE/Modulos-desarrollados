{
    "name": "ChatRoom Pricelist Sync",
    "version": "17.0.1.0.0",
    "category": "Sales",
    "summary": "Aplicar lista de precios del cliente al catálogo de ChatRoom",
    "depends": [
        "whatsapp_connector",
        "product",
    ],
    "data": [],
    "assets": {
        "web.assets_backend": [
            "chatroom_pricelist_sync/static/src/js/patch_product_model.js",
            "chatroom_pricelist_sync/static/src/js/patch_product_container.js",
            "chatroom_pricelist_sync/static/src/js/patch_send.js",
            "chatroom_pricelist_sync/static/src/xml/producto.xml",
            

            
        ],
    },
    "installable": True,
    "license": "LGPL-3",
}
