# -*- coding: utf-8 -*-

from odoo import fields, models


class ProductTemplate(models.Model):
    _inherit = "product.template"

    is_warranty = fields.Boolean("Es Garantía")
    period = fields.Integer("Período de Garantía")
    duration = fields.Selection(
        [("days", "Días"), ("months", "Meses"), ("years", "Años")],
        default="days",
    )
    is_allow_renew = fields.Boolean("¿Permitir Renovación?")
    renew_cost = fields.Float("Costo de Renovación")
    warranty_ids = fields.One2many("sr.product.warranty", "product_id")

    pos_extended_warranty_enabled = fields.Boolean("Aplicar Garantía Extendida en TPV")

    is_extended_warranty = fields.Boolean(
        string="Es Garantía Extendida",
        help="Marque esto si este SKU representa una garantía extendida.",
    )
    related_base_product_id = fields.Many2one(
        "product.template",
        string="Producto Base para Garantía",
        help="Producto cuya garantía será extendida por este SKU.",
        domain="[('sale_ok','=',True)]",
    )

    warranty_service_product_id = fields.Many2one(
        "product.product",
        string="Producto de Servicio para Garantía",
        domain="[('type','=','service')]",
        help="Producto de servicio que se facturará como garantía extendida.",
    )
    warranty_percent = fields.Float(
        string="Porcentaje de Garantía (%)",
        default=10.0,
        help="Porcentaje del precio unitario de la línea base para calcular la garantía extendida.",
    )
