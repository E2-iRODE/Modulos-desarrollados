# -*- coding: utf-8 -*-

from . import inherited_product_template
from . import sr_product_warranty
from . import inherited_sale_order
from . import inherited_res_config_settings
from . import inherited_stock_picking
from . import sr_claim_warranty
from . import inherited_account_move
from . import inherited_pos_order
from . import inherited_pos_order_line
from . import inherited_pos_session

