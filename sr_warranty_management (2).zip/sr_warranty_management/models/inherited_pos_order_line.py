# -*- coding: utf-8 -*-

from odoo import fields, models


class PosOrderLine(models.Model):
    _inherit = "pos.order.line"

    sr_line_uuid = fields.Char(index=True)
    sr_warranty_base_line_uuid = fields.Char(index=True)
    sr_warranty_percent = fields.Float()
    sr_warranty_serial = fields.Char(index=True)
