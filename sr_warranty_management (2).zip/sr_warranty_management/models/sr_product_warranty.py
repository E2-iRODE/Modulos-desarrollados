# -*- coding: utf-8 -*-

from odoo import api, fields, models, _
from datetime import date, timedelta
from functools import reduce
from odoo.exceptions import ValidationError, UserError


class srProductWarranty(models.Model):
    _name = "sr.product.warranty"
    _description = "Garantía de Producto"
    _rec_name = "name"
    _inherit = ["portal.mixin", "mail.thread", "mail.activity.mixin", "utm.mixin"]

    name = fields.Char("Nombre")
    company_id = fields.Many2one("res.company", "Compañía")

    partner_id = fields.Many2one("res.partner", "Cliente")
    phone = fields.Char("Teléfono", related="partner_id.phone")
    email = fields.Char("Correo Electrónico", related="partner_id.email")

    product_id = fields.Many2one("product.template", "Producto")
    product_ref_code = fields.Char("Código de Producto", related="product_id.default_code")
    product_barcode = fields.Char("Código de Barras", related="product_id.barcode")
    serial_number = fields.Char("Número de Serie")
    qty = fields.Float("Cantidad")

    period = fields.Integer("Período de Garantía", related="product_id.period", store=True)
    duration = fields.Selection(related="product_id.duration", store=True)
    renewal_cost = fields.Float("Costo de Renovación", related="product_id.renew_cost", store=True)
    is_allow_renew = fields.Boolean("¿Permitir Renovación?", related="product_id.is_allow_renew")
    start_date = fields.Date("Fecha de Inicio")
    end_date = fields.Date("Fecha de Fin")
    state = fields.Selection(
        [("in_warranty", "En Garantía"), ("expired_warranty", "Garantía Vencida")],
        default="in_warranty",
    )
    warranty_date = fields.Date("Fecha de Garantía")

    # NUEVOS CAMPOS PARA TPV
    pos_order_id = fields.Many2one(
        "pos.order",
        string="Pedido TPV",
        index=True,
        help="Pedido de TPV desde el cual se generó esta garantía."
    )
    pos_order_line_id = fields.Many2one(
        "pos.order.line",
        string="Línea TPV",
        help="Línea del TPV relacionada con esta garantía."
    )

    @api.depends('sale_order_id')
    def _get_sale_order(self):
        for rec in self:
            rec.sale_order_count = 1 if rec.sale_order_id else 0

    def action_view_sale_order(self):
        """Abrir SIEMPRE el formulario de la SO vinculada; si no existe, lista vacía."""
        self.ensure_one()
        if self.sale_order_id:
            form_view = self.env.ref('sale.view_order_form', raise_if_not_found=False)
            return {
                "type": "ir.actions.act_window",
                "name": _("Pedido de Venta"),
                "res_model": "sale.order",
                "view_mode": "form",
                "views": [(form_view.id, "form")] if form_view else [(False, "form")],
                "res_id": self.sale_order_id.id,
                "target": "current",
            }
        return {
            "type": "ir.actions.act_window",
            "name": _("Pedidos de Venta"),
            "res_model": "sale.order",
            "view_mode": "list,form",
            "domain": [("id", "=", 0)],
        }

    def action_view_repair_order(self):
        """Si hay 1 OR: abre form. Si hay varias: listado filtrado por esta garantía."""
        self.ensure_one()
        Repair = self.env['repair.order']
        domain = [('warranty_id', '=', self.id)]
        count = Repair.search_count(domain)
        if count == 1:
            ro = Repair.search(domain, limit=1)
            form_view = self.env.ref('repair.repair_order_form_view', raise_if_not_found=False)
            return {
                'type': 'ir.actions.act_window',
                'name': _('Orden de Reparación'),
                'res_model': 'repair.order',
                'view_mode': 'form',
                'views': [(form_view.id, 'form')] if form_view else [(False, 'form')],
                'res_id': ro.id,
                'target': 'current',
            }
        return {
            'type': 'ir.actions.act_window',
            'name': _('Órdenes de Reparación'),
            'res_model': 'repair.order',
            'view_mode': 'list,form',
            'domain': domain,
            'target': 'current',
        }

    def _compute_repair_orders(self):
        for rec in self:
            rec.repair_order_count = self.env['repair.order'].search_count([
                ('warranty_id', '=', rec.id)
            ])

    warranty_kind = fields.Selection(
        [('standard', 'Normal'), ('extended', 'Extendida')],
        string="Tipo de garantía",
        required=True,
        default='standard',
        tracking=True,
        index=True,
    )
    base_warranty_id = fields.Many2one(
        'sr.product.warranty',
        string='Garantía base',
        domain="[('warranty_kind','=','standard'), ('id','!=',id), ('partner_id','=',partner_id), ('product_id','=',product_id)]",
        help="Garantía normal a la que está vinculada esta extensión."
    )
    extended_warranty_ids = fields.One2many('sr.product.warranty', 'base_warranty_id', string='Extensiones')

    sale_order_line_id = fields.Many2one("sale.order.line", "Línea de Pedido de Venta")
    sale_order_id = fields.Many2one(
        "sale.order", string="Pedido de Venta",
        related="sale_order_line_id.order_id", store=True, readonly=True
    )
    sale_order_count = fields.Integer("Cantidad de Pedidos de Venta", compute="_get_sale_order")

    repair_order_ids = fields.One2many('repair.order', 'warranty_id', string='Órdenes de Reparación')
    repair_order_count = fields.Integer(string="Cantidad de Órdenes de Reparación", compute="_compute_repair_orders")

    invoice_id = fields.Many2one("account.move", "Factura")
    invoice_count = fields.Integer(string="Cantidad de Facturas", compute="_get_invoice")

    history_ids = fields.One2many("sr.history.warranty", "warranty_id")

    claim_ids = fields.One2many(
        comodel_name="sr.claim.warranty",
        inverse_name="warranty_id",
        string="Reclamos",
        readonly=True,
    )

    claim_id = fields.Many2one("sr.claim.warranty", string="Reclamo relacionado")

    claim_count = fields.Integer(string="Cantidad de reclamos", compute="_get_claim")

    can_claim = fields.Boolean(string="¿Se puede reclamar?", compute="_compute_can_claim")

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if vals.get("name", "New") == "New":
                vals["name"] = self.env["ir.sequence"].next_by_code("sr.product.warranty") or "New"
        records = super().create(vals_list)
        return records

    @api.model
    def default_get(self, fields_list):
        res = super().default_get(fields_list)
        base_id = (self.env.context or {}).get('default_base_warranty_id')
        if base_id:
            base = self.browse(base_id)
            if base and base.exists():
                res.setdefault('warranty_kind', 'extended')
                if 'partner_id' in fields_list:
                    res['partner_id'] = base.partner_id.id
                if 'product_id' in fields_list:
                    res['product_id'] = base.product_id.id
                if 'serial_number' in fields_list:
                    res['serial_number'] = base.serial_number
                if 'start_date' in fields_list and base.end_date:
                    res['start_date'] = base.end_date
        return res

    def _get_claim(self):
        Claim = self.env["sr.claim.warranty"]
        for rec in self:
            rec.claim_count = Claim.search_count([("warranty_id", "=", rec.id)])

    def open_view_claim_action(self):
        return {
            "name": "Reclamo",
            "type": "ir.actions.act_window",
            "view_mode": "list,form",
            "res_model": "sr.claim.warranty",
            "views": [(False, "list"), (False, "form")],
            "domain": [("warranty_id", "=", self.id)],
        }

    def _get_invoice(self):
        Move = self.env["account.move"]
        domain_base = [("move_type", "=", "out_invoice"), ('is_warranty', '=', True)]
        for rec in self:
            rec.invoice_count = Move.search_count([("warranty_id", "=", rec.id)] + domain_base)

    def open_view_invoice_action(self):
        return {
            "name": "Facturas",
            "type": "ir.actions.act_window",
            "view_mode": "list,form",
            "res_model": "account.move",
            "views": [(False, "list"), (False, "form")],
            "domain": [("warranty_id", "=", self.id), ("move_type", "=", "out_invoice"), ('is_warranty', '=', True)],
        }

    def cron_warranty_expired_validity(self):
        for w in self.search([("state", "=", "in_warranty")]):
            if w.end_date == date.today():
                w.state = "expired_warranty"

    def renew_warranty(self):
        action = self.env.ref("sr_warranty_management.sr_renew_warranty_action").read()[0]
        action["context"] = {"default_renew_cost": self.renewal_cost}
        return action

    def claim_warranty(self):
        self.ensure_one()
        if self.state == 'expired_warranty':
            raise ValidationError(_("Esta garantía ha vencido y ya no puede ser reclamada."))
        if not self.can_claim:
            raise ValidationError(_("Esta garantía ya tiene un reclamo activo."))
        return self.env.ref("sr_warranty_management.sr_claim_warranty_wizard_action").read()[0]

    @api.onchange('serial_number', 'partner_id', 'product_id', 'warranty_kind')
    def _onchange_base_warranty_id(self):
        if self.warranty_kind == 'extended' and self.serial_number and self.partner_id and self.product_id:
            base = self.search([
                ('warranty_kind', '=', 'standard'),
                ('partner_id', '=', self.partner_id.id),
                ('product_id', '=', self.product_id.id),
                ('serial_number', '=', self.serial_number),
            ], limit=1, order='end_date desc')
            if base:
                self.base_warranty_id = base.id

    @api.constrains('warranty_kind', 'base_warranty_id')
    def _check_extended_links(self):
        for rec in self:
            if rec.warranty_kind == 'extended' and not rec.base_warranty_id:
                raise ValidationError(_("La garantía extendida debe estar vinculada a una garantía base."))
            if rec.warranty_kind == 'standard' and rec.base_warranty_id:
                raise ValidationError(_("Una garantía normal no puede tener garantía base."))

    @api.constrains('warranty_kind', 'start_date', 'end_date', 'base_warranty_id')
    def _check_dates_no_overlap(self):
        for rec in self:
            if rec.warranty_kind == 'extended' and rec.base_warranty_id and rec.start_date and rec.base_warranty_id.end_date:
                if rec.start_date < rec.base_warranty_id.end_date:
                    raise ValidationError(_("La garantía extendida debe iniciar el mismo día o después de que finaliza la garantía base."))

    def cron_warranty_expire_notification(self):
        company = self.env.user.company_id
        if not company or not company.period:
            return
        warranty_ids = self.search([("state", "=", "in_warranty"), ("company_id", "=", company.id)])
        for partner in warranty_ids.mapped("partner_id"):
            partner_warr = warranty_ids.filtered(lambda x: x.partner_id == partner)
            date_list = reduce(lambda re, x: re + [x] if x not in re else re, partner_warr.mapped("end_date"), [])
            for d in date_list:
                date_partner_warr_ids = partner_warr.filtered(lambda x: x.end_date == d)
                rows = []
                for w in date_partner_warr_ids:
                    if w.end_date - timedelta(days=company.period) == date.today():
                        rows.append((w.product_id.name, w.start_date, w.end_date, w.name))
                if rows:
                    if len(rows) == 1:
                        p, s, e, n = rows[0]
                        self.send_mail_data([partner.id], partner.name, [p], [s], [e], [n])
                    else:
                        p, s, e, n = zip(*rows)
                        self.send_mail_mul_data([partner.id], partner.name, list(p), list(s), list(e), list(n))

    @api.depends('state', 'warranty_kind', 'base_warranty_id',
                 'claim_ids.state', 'base_warranty_id.claim_ids.state')
    def _compute_can_claim(self):
        ACTIVE_STATES = {'draft', 'review', 'repair'}
        Claim = self.env['sr.claim.warranty']

        def has_active_claim(warr):
            return bool(warr and Claim.search([('warranty_id', '=', warr.id),
                                               ('state', 'in', list(ACTIVE_STATES))], limit=1))

        for rec in self:
            if rec.state != 'in_warranty':
                rec.can_claim = False
            elif rec.warranty_kind == 'extended' and rec.base_warranty_id:
                rec.can_claim = not (has_active_claim(rec) or has_active_claim(rec.base_warranty_id))
            else:
                rec.can_claim = not has_active_claim(rec)

    def send_mail_data(self, email_to, warranty_partner, product_list, start_date_list, end_date_list, warranty_list):
        msg = '<table style="border: 1px solid black;"><tbody><tr>' \
              '<th style="width:135px;border: 1px solid black; text-align:center;">Producto</th>' \
              '<th style="width:135px;border: 1px solid black; text-align:center;">Fecha de Inicio</th>' \
              '<th style="width:135px;border: 1px solid black; text-align:center;">Fecha de Fin</th>' \
              '<th style="width:135px;border: 1px solid black; text-align:center;">Garantía</th>'
        for i, product in enumerate(product_list or []):
            msg += ('<tr><td style="border:1px solid black;text-align:center;">%s</td>'
                    '<td style="border:1px solid black;text-align:center;">%s</td>'
                    '<td style="border:1px solid black;text-align:center;">%s</td>'
                    '<td style="border:1px solid black;text-align:center;">%s</td></tr>') % (
                       product, start_date_list[i], end_date_list[i], warranty_list[i])
        msg += "</tbody></table/>"
        if msg:
            self.send_mail(email_to, warranty_partner, msg)

    def send_mail_mul_data(self, email_to, warranty_partner, mul_product_list, mul_start_date_list, mul_end_date_list, mul_warranty_list):
        return self.send_mail_data(email_to, warranty_partner, mul_product_list, mul_start_date_list, mul_end_date_list, mul_warranty_list)

    def send_mail(self, email_to, warranty_partner, output):
        if email_to and output:
            mail = {
                "subject": "Notificación de Vencimiento de Garantía",
                "email_from": self.env.user.name,
                "recipient_ids": [(6, 0, email_to)],
                "body_html": """<font size="2">
                    <p>Hola {0}</p><p>La garantía de su producto vencerá en:</p>
                    <p>{1}</p><p>Saludos cordiales,</p><p>{2}</p></font>""".format(
                    warranty_partner, output, self.env.user.name),
            }
            mail_id = self.env["mail.mail"].create(mail)
            if mail_id:
                mail_id.send()

    def action_create_repair_order(self):
        self.ensure_one()
        if not self.product_id:
            raise UserError(_("Debe asignar un producto a la garantía."))
        if not self.partner_id:
            raise UserError(_("Debe asignar un cliente a la garantía."))

        Repair = self.env['repair.order']
        Lot = self.env['stock.lot'].sudo()
        product_variant_id = self.product_id.product_variant_id.id
        lot_id = False

        if self.serial_number:
            lot = Lot.search([
                ('product_id', '=', product_variant_id),
                ('name', '=', self.serial_number),
                ('company_id', '=', self.company_id.id)
            ], limit=1)
            if not lot and self.product_id.tracking == 'serial':
                lot = Lot.create({
                    'name': self.serial_number,
                    'product_id': product_variant_id,
                    'company_id': self.company_id.id
                })
            lot_id = lot.id if lot else False

        OPEN_STATES = ('draft', 'confirmed', 'under_repair')

        existing = Repair.search([
            ('warranty_id', '=', self.id),
            ('state', 'in', OPEN_STATES),
        ], limit=1)

        if existing:
            return {
                'name': _('Orden de Reparación'),
                'type': 'ir.actions.act_window',
                'res_model': 'repair.order',
                'view_mode': 'form',
                'res_id': existing.id,
                'target': 'current'
            }

        ctx = {
            'default_partner_id': self.partner_id.id,
            'default_product_id': product_variant_id,
            'default_product_qty': self.qty or 1.0,
            'default_company_id': self.company_id.id,
            'default_lot_id': lot_id,
            'default_warranty_id': self.id,
        }
        return {
            'name': _('Orden de Reparación'),
            'type': 'ir.actions.act_window',
            'res_model': 'repair.order',
            'view_mode': 'form',
            'target': 'current',
            'context': ctx,
        }


class srHistoryWarranty(models.Model):
    _name = "sr.history.warranty"
    _description = "Historial de Garantía"

    warranty_id = fields.Many2one("sr.product.warranty")
    partner_id = fields.Many2one("res.partner", "Cliente")
    product_id = fields.Many2one("product.template", "Producto")
    serial_number = fields.Char("Número de Serie")
    start_date = fields.Date("Fecha de Inicio")
    end_date = fields.Date("Fecha de Fin")
    renewal_cost = fields.Float("Costo de Renovación")


class SaleOrder(models.Model):
    _inherit = 'sale.order'

    warranty_percent = fields.Float(
        string="Porcentaje garantía (%)", default=10.0,
        help="Porcentaje del precio unitario de la línea base para calcular la garantía extendida."
    )
    warranty_service_product_id = fields.Many2one(
        'product.product', string="Producto servicio garantía",
        help="Producto de servicio que representa la garantía extendida."
    )

    def action_add_extended_warranty_footer(self):
        """Crear/actualizar líneas de garantía extendida para líneas elegibles."""
        self.ensure_one()
        order = self

        candidates = order.order_line.filtered(
            lambda l: not l.display_type and not getattr(l, 'is_warranty', False) and l.product_id
        )
        if not candidates:
            raise UserError(_("No hay líneas de producto elegibles para agregar garantía."))

        decimals = order.currency_id.decimal_places or 2

        for base_line in candidates:
            tmpl = base_line.product_id.product_tmpl_id
            service_product = tmpl.warranty_service_product_id
            if not service_product:
                raise UserError(_("Configura el 'Servicio de garantía' en el producto '%s'.")
                                % base_line.product_id.display_name)
            if service_product.type != 'service':
                raise UserError(_("El producto de garantía '%s' debe ser de tipo Servicio.")
                                % service_product.display_name)

            percent = float(tmpl.warranty_percent or 0.0)
            base_price = base_line.price_unit or base_line.product_id.list_price or 0.0
            warranty_price = round(base_price * (percent / 100.0), decimals)

            name = (service_product.get_product_multiline_description_sale() or service_product.display_name) + \
                   _(" — Garantía extendida de %s%% sobre %s") % (percent, base_line.product_id.display_name)

            existing = order.order_line.filtered(
                lambda l: getattr(l, 'is_warranty', False) and l.warranty_base_line_id.id == base_line.id
            )

            if existing:
                vals_upd = {
                    'product_id': service_product.id,
                    'name': name,
                    'tax_id': [(6, 0, service_product.taxes_id.ids)],
                    'is_warranty': True,
                    'warranty_base_line_id': base_line.id,
                }
                existing.write(vals_upd)
                for line in existing:
                    if not line.price_unit or line.price_unit == 0.0:
                        line.price_unit = warranty_price
                    if not line.product_uom_qty or line.product_uom_qty <= 0.0:
                        line.product_uom_qty = base_line.product_uom_qty or 1.0
            else:
                order.order_line.create({
                    'order_id': order.id,
                    'product_id': service_product.id,
                    'name': name,
                    'product_uom_qty': base_line.product_uom_qty or 1.0,
                    'price_unit': warranty_price,
                    'tax_id': [(6, 0, service_product.taxes_id.ids)],
                    'sequence': (base_line.sequence or 10) + 1,
                    'is_warranty': True,
                    'warranty_base_line_id': base_line.id,
                })
        return True


class SaleOrderLine(models.Model):
    _inherit = 'sale.order.line'

    is_warranty = fields.Boolean(string="Es garantía", default=False, copy=False)
    warranty_base_line_id = fields.Many2one(
        'sale.order.line', string="Línea base",
        help="Línea de producto a la que está ligada esta garantía.",
        copy=False
    )

    def action_add_extended_warranty_line(self):
        self.ensure_one()
        line = self
        order = line.order_id

        if line.is_warranty:
            raise UserError(_("Esta línea ya es una garantía. Selecciona una línea de producto."))
        if not line.product_id:
            raise UserError(_("Selecciona un producto primero."))

        tmpl = line.product_id.product_tmpl_id
        service_product = tmpl.warranty_service_product_id
        if not service_product:
            raise UserError(_("Configura el 'Servicio de garantía' en el PRODUCTO (Inventario → Producto) marcando 'Is Warranty'."))
        if service_product.type != 'service':
            raise UserError(_("El producto de garantía debe ser de tipo Servicio."))

        existing = order.order_line.filtered(lambda l: l.is_warranty and l.warranty_base_line_id.id == line.id)
        if existing:
            raise UserError(_("Ya existe una garantía extendida para esta línea."))

        percent = tmpl.warranty_percent or 0.0
        warranty_price = round(line.price_unit * (percent / 100.0), 2)
        new_sequence = (line.sequence or 10) + 1

        vals = {
            'order_id': order.id,
            'product_id': service_product.id,
            'name': (service_product.get_product_multiline_description_sale() or service_product.display_name)
                    + _(" — Garantía extendida de %s%% sobre %s") % (percent, line.product_id.display_name),
            'product_uom_qty': line.product_uom_qty or 1.0,
            'price_unit': warranty_price,
            'tax_id': [(6, 0, service_product.taxes_id.ids)],
            'sequence': new_sequence,
            'is_warranty': True,
            'warranty_base_line_id': line.id,
        }
        order.order_line.create(vals)
        return True


class SrWarrantySerialWizard(models.TransientModel):
    _name = 'sr.warranty.serial.wizard'
    _description = 'Asignar seriales a garantías'

    sale_id = fields.Many2one('sale.order', required=True)
    line_ids = fields.One2many('sr.warranty.serial.wizard.line', 'wizard_id', string='Seriales')

    @api.model
    def default_get(self, fields_list):
        res = super().default_get(fields_list)
        sale = self.env['sale.order'].browse(self.env.context.get('default_sale_id') or res.get('sale_id'))
        if sale:
            res['sale_id'] = sale.id
            commands = []
            w_lines = sale.order_line.filtered(lambda l: not l.display_type and getattr(l, 'is_warranty', False) and l.product_uom_qty > 0)
            for wl in w_lines:
                base = wl.warranty_base_line_id
                for _ in range(int(wl.product_uom_qty or 0)):
                    commands.append((0, 0, {
                        'base_line_id': base.id if base else False,
                        'product_id': base.product_id.id if base and base.product_id else False,
                    }))
            res['line_ids'] = commands
        return res

    def action_confirm_serials(self):
        self.ensure_one()
        if not self.line_ids:
            return self._notify(_("Debes ingresar al menos un serial."))

        serials = [s.serial_number.strip() for s in self.line_ids if s.serial_number]
        if len(serials) != len(set(serials)):
            return self._notify(_("Hay números de serie repetidos en el asistente. Corrige y vuelve a confirmar."))

        if serials:
            exists = self.env['sr.product.warranty'].sudo().search([('serial_number', 'in', serials)], limit=1)
            if exists:
                return self._notify(_("El número de serie '%s' ya existe en otra garantía.") % exists.serial_number)

        sale = self.sale_id
        sale.with_context(serials_done=True).action_confirm()

        Warranty = self.env['sr.product.warranty'].sudo()

        for wline in self.line_ids.sorted(key=lambda r: (r.base_line_id.id or 0, r.id)):
            if not wline.serial_number:
                continue
            domain_std = [
                ('sale_order_id', '=', sale.id),
                ('warranty_kind', 'in', ['standard', False]),
                ('serial_number', '=', False),
            ]
            if wline.base_line_id:
                domain_std += [('sale_order_line_id', '=', wline.base_line_id.id)]
            std = Warranty.search(domain_std, limit=1, order='id asc')
            if std:
                std.write({'serial_number': wline.serial_number})
                exts = Warranty.search([
                    ('sale_order_id', '=', sale.id),
                    ('warranty_kind', '=', 'extended'),
                    ('base_warranty_id', '=', std.id),
                ])
                if exts:
                    exts.write({'serial_number': wline.serial_number})
        return {'type': 'ir.actions.act_window_close'}

    def _notify(self, msg, title=_("Error de validación")):
        self._rehydrate_lines()
        if hasattr(self.env.user, 'notify_warning'):
            self.env.user.notify_warning(message=msg, title=title)
        return {
            'name': _("Asignar serial(es)"),
            'type': 'ir.actions.act_window',
            'res_model': self._name,
            'view_mode': 'form',
            'res_id': self.id,
            'target': 'new',
            'context': dict(self.env.context),
        }

    def _rehydrate_lines(self):
        self.ensure_one()
        sale = self.sale_id
        if not sale:
            return
        base_seq = []
        for wl in sale.order_line.filtered(lambda l: not l.display_type and getattr(l, 'is_warranty', False) and l.product_uom_qty > 0):
            base = wl.warranty_base_line_id
            for _ in range(int(wl.product_uom_qty or 0)):
                base_seq.append(base)
        for idx, wline in enumerate(self.line_ids.sorted(key=lambda r: r.id)):
            if (not wline.base_line_id) and idx < len(base_seq) and base_seq[idx]:
                base = base_seq[idx]
                wline.write({
                    'base_line_id': base.id,
                    'product_id': base.product_id.id if base.product_id else False,
                    'serial_number': wline.serial_number or ''
                })


class SrWarrantySerialWizardLine(models.TransientModel):
    _name = 'sr.warranty.serial.wizard.line'
    _description = 'Detalle de serial por unidad'

    wizard_id = fields.Many2one('sr.warranty.serial.wizard', required=True, ondelete='cascade')
    base_line_id = fields.Many2one('sale.order.line', string='Línea base', required=False)
    product_id = fields.Many2one('product.product', string='Producto', required=False)
    serial_number = fields.Char(string='Serial', required=True)


class RepairOrder(models.Model):
    _inherit = 'repair.order'

    warranty_id = fields.Many2one('sr.product.warranty', string='Garantía', index=True)


