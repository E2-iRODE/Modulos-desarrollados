# -*- coding: utf-8 -*-

from odoo import api, fields, models, _


class ResCompany(models.Model):
    _inherit = "res.company"

    period = fields.Integer(
        "Notificación de Expiración de Garantía", store=True, default=1
    )


class ResConfigSettings(models.TransientModel):
    _inherit = "res.config.settings"

    period = fields.Integer(
        "Notificación de Expiración de Garantía",
        related="company_id.period",
        readonly=False
    )
