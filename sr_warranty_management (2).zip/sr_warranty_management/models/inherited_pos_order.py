# -*- coding: utf-8 -*-
from datetime import date, timedelta

from dateutil.relativedelta import relativedelta
from odoo import fields, models, _


class PosOrder(models.Model):
    _inherit = "pos.order"

    warranty_ids = fields.One2many("sr.product.warranty", "pos_order_id", string="Garantías")
    warranty_count = fields.Integer(string="Nº Garantías", compute="_compute_warranty_count")

    def _compute_warranty_count(self):
        for order in self:
            order.warranty_count = len(order.warranty_ids)

    def action_view_warranties(self):
        self.ensure_one()
        action = self.env.ref("sr_warranty_management.sr_product_warranty_action").read()[0]
        action["domain"] = [("pos_order_id", "=", self.id)]
        action["context"] = {
            "default_pos_order_id": self.id,
            "default_partner_id": self.partner_id.id,
            "search_default_in_warranty": 1,
        }
        return action

    def _order_line_fields(self, line, session_id=None):
        res = super()._order_line_fields(line, session_id) if session_id is not None else super()._order_line_fields(line)
        data = line[2] if isinstance(line, (list, tuple)) and len(line) > 2 else {}
        if isinstance(data, dict):
            res["sr_warranty_base_line_uuid"] = data.get("sr_warranty_base_line_uuid") or False
            res["sr_warranty_percent"] = data.get("sr_warranty_percent") or False
            res["sr_line_uuid"] = data.get("sr_line_uuid") or data.get("uuid") or False
            serial = (data.get("sr_warranty_serial") or "").strip()
            res["sr_warranty_serial"] = serial or False
        return res

    def _date_add(self, start, period, duration):
        if not start or not period or not duration:
            return False
        if duration == "days":
            return start + timedelta(days=int(period))
        if duration == "weeks":
            return start + timedelta(weeks=int(period))
        if duration == "months":
            return start + relativedelta(months=int(period))
        if duration == "years":
            return start + relativedelta(years=int(period))
        return False

    def _pos_base_lines(self, order):
        return order.lines.filtered(lambda l: l.product_id and not getattr(l, "sr_warranty_base_line_uuid", False))

    def _pos_service_lines(self, order):
        return order.lines.filtered(lambda l: l.product_id and bool(getattr(l, "sr_warranty_base_line_uuid", False)))

    def _create_standard_warranties(self, order, start_today):
        Warranty = self.env["sr.product.warranty"]
        base_map_by_line = {}

        for line in self._pos_base_lines(order):
            product = line.product_id
            tmpl = product.product_tmpl_id

            if not getattr(tmpl, "period", False) or not getattr(tmpl, "duration", False):
                continue

            qty = int(max(line.qty, 0.0))
            if qty <= 0:
                continue

            end = self._date_add(start_today, tmpl.period, tmpl.duration)
            if not end:
                continue

            existing_std = Warranty.search(
                [
                    ("pos_order_id", "=", order.id),
                    ("pos_order_line_id", "=", line.id),
                    ("warranty_kind", "=", "standard"),
                ],
                order="id asc",
            )
            created_ids = existing_std.ids[:]
            needed = qty - len(existing_std)

            for _i in range(max(needed, 0)):
                w = Warranty.sudo().create(
                    {
                        "name": "%s - %s" % (order.name or _("Ticket TPV"), product.display_name),
                        "partner_id": order.partner_id.id or False,
                        "product_id": tmpl.id,
                        "qty": 1,
                        "start_date": start_today,
                        "end_date": end,
                        "company_id": order.company_id.id,
                        "warranty_date": date.today(),
                        "warranty_kind": "standard",
                        "pos_order_id": order.id,
                        "pos_order_line_id": line.id,
                    }
                )
                created_ids.append(w.id)

            base_map_by_line[line.id] = created_ids

        return base_map_by_line

    def _resolve_base_line_for_service(self, order, service_line, uuid_to_lineid):
        base_uuid = getattr(service_line, "sr_warranty_base_line_uuid", False)
        if base_uuid:
            base_line_id = uuid_to_lineid.get(base_uuid)
            if base_line_id:
                base_line = order.lines.filtered(lambda l: l.id == base_line_id)[:1]
                if base_line:
                    return base_line

        candidates = self._pos_base_lines(order).filtered(lambda l: l.product_id)
        return candidates[:1] if candidates else False

    def _is_valid_service_for_base(self, base_tmpl, service_product):
        service_cfg = getattr(base_tmpl, "warranty_service_product_id", False)
        if not service_cfg:
            return False
        return service_cfg.id == service_product.id

    def _extended_policy(self, base_tmpl, service_tmpl):
        period = service_tmpl.period or base_tmpl.period
        duration = service_tmpl.duration or base_tmpl.duration
        return period, duration

    def _parse_serials(self, raw):
        txt = (raw or "").strip()
        if not txt:
            return []
        parts = [p.strip() for p in txt.replace("\n", ",").split(",")]
        return [p for p in parts if p]

    def _create_extended_warranties(self, order, start_today, base_map_by_line, uuid_to_lineid):
        Warranty = self.env["sr.product.warranty"]

        for sline in self._pos_service_lines(order):
            service_product = sline.product_id
            service_tmpl = service_product.product_tmpl_id

            base_line = self._resolve_base_line_for_service(order, sline, uuid_to_lineid)
            if not base_line or not base_line.product_id:
                continue

            base_tmpl = base_line.product_id.product_tmpl_id
            if not getattr(base_tmpl, "pos_extended_warranty_enabled", False):
                continue

            if not self._is_valid_service_for_base(base_tmpl, service_product):
                continue

            qty = int(max(sline.qty, 0.0))
            if qty <= 0:
                continue

            serials = self._parse_serials(getattr(sline, "sr_warranty_serial", False))
            if len(serials) != qty or len(set(serials)) != len(serials):
                continue

            base_ids = base_map_by_line.get(base_line.id)
            if not base_ids:
                base_ids = Warranty.search(
                    [
                        ("pos_order_id", "=", order.id),
                        ("pos_order_line_id", "=", base_line.id),
                        ("warranty_kind", "in", ["standard", False]),
                    ],
                    order="id asc",
                ).ids

            if not base_ids:
                continue

            period, duration = self._extended_policy(base_tmpl, service_tmpl)
            if not period or not duration:
                continue

            existing_ext = Warranty.search(
                [
                    ("pos_order_id", "=", order.id),
                    ("pos_order_line_id", "=", sline.id),
                    ("warranty_kind", "=", "extended"),
                ],
                order="id asc",
            )

            used_base_ids = set(existing_ext.mapped("base_warranty_id").ids)
            available_base_ids = [bid for bid in base_ids if bid not in used_base_ids]
            needed_ext = qty - len(existing_ext)

            base_product_label = base_line.product_id.display_name
            service_label = service_product.display_name
            ticket_label = order.name or _("Ticket TPV")
            name_tpl = "%s - %s — sobre %s" % (ticket_label, service_label, base_product_label)

            for i in range(max(needed_ext, 0)):
                if i >= len(available_base_ids) or i >= len(serials):
                    break

                base_warr = Warranty.browse(available_base_ids[i])
                start = base_warr.end_date or start_today
                end = self._date_add(start, period, duration)
                if not end:
                    continue

                Warranty.sudo().create(
                    {
                        "name": name_tpl,
                        "partner_id": order.partner_id.id or False,
                        "product_id": service_tmpl.id,
                        "qty": 1,
                        "start_date": start,
                        "end_date": end,
                        "company_id": order.company_id.id,
                        "warranty_date": date.today(),
                        "warranty_kind": "extended",
                        "pos_order_id": order.id,
                        "pos_order_line_id": sline.id,
                        "base_warranty_id": base_warr.id,
                        "serial_number": serials[i],
                    }
                )

    def _create_warranty_records_from_pos(self):
        Warranty = self.env["sr.product.warranty"]

        for order in self:
            if not order.lines:
                continue

            start_today = fields.Date.context_today(order)

            uuid_to_lineid = {}
            for line in order.lines:
                if getattr(line, "uuid", False):
                    uuid_to_lineid[line.uuid] = line.id
                elif getattr(line, "sr_line_uuid", False):
                    uuid_to_lineid[line.sr_line_uuid] = line.id

            base_map_by_line = self._create_standard_warranties(order, start_today)
            self._create_extended_warranties(order, start_today, base_map_by_line, uuid_to_lineid)

            all_warr = Warranty.search([("pos_order_id", "=", order.id)]).ids
            order.warranty_ids = [(6, 0, all_warr)]

    def action_pos_order_paid(self):
        res = super().action_pos_order_paid()
        self._create_warranty_records_from_pos()
        return res
