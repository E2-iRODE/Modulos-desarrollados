# -*- coding: utf-8 -*-

from odoo import models


class PosSession(models.Model):
    _inherit = "pos.session"

    def _loader_params_pos_order_line(self):
        res = super()._loader_params_pos_order_line()
        fields = res["search_params"].setdefault("fields", [])
        for f in ("sr_line_uuid", "sr_warranty_base_line_uuid", "sr_warranty_percent", "sr_warranty_serial"):
            if f not in fields:
                fields.append(f)
        return res
