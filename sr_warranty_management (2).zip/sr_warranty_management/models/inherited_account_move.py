# -*- coding: utf-8 -*-

from odoo import api, fields, models, _


class AccountMove(models.Model):
    _inherit = "account.move"

    warranty_id = fields.Many2one("sr.product.warranty")
    warranty_count = fields.Integer(
        string="Cantidad de Garantías", compute="_get_warranty")
    is_warranty = fields.Boolean("#Es Garantía")

    def _get_warranty(self):
        self.warranty_count = self.env["sr.product.warranty"].search_count(
            [("invoice_id", "=", self.id)]
        )

    def action_warranty_view(self):
        return {
            "name": "Garantía",
            "type": "ir.actions.act_window",
            "view_mode": "list,form",
            "res_model": "sr.product.warranty",
            "views": [(False, "list"), (False, "form")],
            "domain": [("invoice_id", "=", self.id)],
        }
