# -*- coding: utf-8 -*-

from odoo import api, fields, models, _
import datetime
from datetime import date
from dateutil.relativedelta import relativedelta
from odoo.exceptions import UserError


class SaleOrder(models.Model):
    _inherit = "sale.order"

    warranty_ids = fields.Many2many(comodel_name="sr.product.warranty")
    warranty_count = fields.Integer(string="Cantidad de Garantías", compute="_get_warranty")
    is_warranty = fields.Boolean("#Es Garantía")

    claim_id = fields.Many2one("sr.claim.warranty")
    claim_count = fields.Integer("Cantidad de Reclamos", compute="_get_claim")

    def copy_data(self, default=None):
        result = super().copy_data(default)
        if "warranty_ids" in result[0] and result[0]["warranty_ids"]:
            result[0]["warranty_ids"] = []
        if "order_line" in result[0] and result[0]["order_line"]:
            for line in result[0]["order_line"]:
                if "warranty_id" in line[2]:
                    line[2]["warranty_id"] = False
        return result

    def _get_warranty(self):
        self.warranty_count = self.env["sr.product.warranty"].search_count(
            [("sale_order_id", "=", self.id)]
        )

    def action_view_warranty(self):
        action = self.env.ref(
            "sr_warranty_management.sr_product_warranty_action"
        ).read()[0]
        action["views"] = [
            (self.env.ref("sr_warranty_management.sr_product_warranty_tree_view").id, "list"),
            (self.env.ref("sr_warranty_management.sr_product_warranty_form_view").id, "form"),
        ]
        action["domain"] = [("sale_order_id", "=", self.id)]
        return action

    def _get_claim(self):
        self.claim_count = self.env["sr.claim.warranty"].search_count(
            [("sale_order_id", "=", self.id)]
        )

    def action_view_claim_warranty(self):
        return {
            "name": "Reclamo de Garantía",
            "type": "ir.actions.act_window",
            "view_mode": "list,form",
            "res_model": "sr.claim.warranty",
            "views": [(False, "list"), (False, "form")],
            "domain": [("sale_order_id", "=", self.id)],
        }

    def action_add_extended_warranty_footer(self):
        self.ensure_one()

        wizard = self.env['sr.extended.warranty.wizard'].create({
            'sale_order_id': self.id,
        })

        lines_vals = []

        for line in self.order_line:
            if line.display_type:
                continue
            if getattr(line, 'is_warranty', False):
                continue
            if not line.product_id:
                continue

            tmpl = line.product_id.product_tmpl_id
            service_product = getattr(tmpl, 'warranty_service_product_id', False)
            if not service_product:
                continue

            existing = self.order_line.filtered(
                lambda l: getattr(l, 'is_warranty', False) and l.warranty_base_line_id.id == line.id
            )
            qty_current = sum(existing.mapped('product_uom_qty')) if existing else 0.0

            lines_vals.append((0, 0, {
                'wizard_id': wizard.id,
                'sale_line_id': line.id,
                'product_id': line.product_id.id,
                'qty_ordered': line.product_uom_qty,
                'qty_current': qty_current,
                'qty_desired': qty_current,
            }))

        wizard.write({'line_ids': lines_vals})

        return {
            'name': _('Garantías Extendidas'),
            'type': 'ir.actions.act_window',
            'res_model': 'sr.extended.warranty.wizard',
            'view_mode': 'form',
            'res_id': wizard.id,
            'target': 'new',
        }

    def create_warranty_records(self, sale_id):
        """
        Crea garantías faltantes de forma idempotente:
          - 'standard' por cada unidad de líneas base (producto con is_warranty=True).
          - 'extended' por cada unidad de líneas de servicio (is_warranty=True en la SOL)
            enlazadas a su base. Nunca duplica si ya existen.
        """
        Warranty = self.env["sr.product.warranty"]
        if not sale_id or not sale_id.order_line:
            return

        base_map = {}
        for line in sale_id.order_line:
            if getattr(line, "is_warranty", False):
                continue
            if not (line.product_id and line.product_id.is_warranty):
                continue

            existing_std = Warranty.search([
                ('sale_order_id', '=', sale_id.id),
                ('sale_order_line_id', '=', line.id),
                ('warranty_kind', 'in', ['standard', False]),
            ], order='id asc')
            needed = int(line.product_uom_qty or 0) - len(existing_std)

            start_dt = line.order_id.date_order or fields.Datetime.now()
            if line.product_id.duration == "days":
                end_dt = start_dt + datetime.timedelta(days=line.product_id.period)
            elif line.product_id.duration == "months":
                end_dt = start_dt + relativedelta(months=+line.product_id.period)
            elif line.product_id.duration == "years":
                end_dt = start_dt + relativedelta(years=+line.product_id.period)
            else:
                end_dt = False

            start_date = start_dt if end_dt else False
            end_date = end_dt if end_dt else False

            created_ids = existing_std.ids[:]
            for _ in range(max(0, needed)):
                vals = {
                    "partner_id": line.order_id.partner_id.id,
                    "product_id": line.product_id.product_tmpl_id.id,
                    "start_date": start_date,
                    "end_date": end_date,
                    "company_id": sale_id.company_id.id,
                    "qty": 1,
                    "warranty_date": date.today(),
                    "sale_order_id": line.order_id.id,
                    "sale_order_line_id": line.id,
                    "warranty_kind": "standard",
                }
                w = Warranty.sudo().create(vals)
                created_ids.append(w.id)
            base_map[line.id] = created_ids

        for line in sale_id.order_line:
            if not getattr(line, "is_warranty", False):
                continue

            base_line = line.warranty_base_line_id
            if not base_line:
                candidates = sale_id.order_line.filtered(
                    lambda l: not getattr(l, "is_warranty", False) and l.product_id
                )
                base_line = candidates[:1]

            if not base_line:
                continue

            existing_ext = Warranty.search([
                ('sale_order_id', '=', sale_id.id),
                ('sale_order_line_id', '=', line.id),
                ('warranty_kind', '=', 'extended'),
            ], order='id asc')
            needed_ext = int(line.product_uom_qty or 0) - len(existing_ext)

            base_warr_ids = base_map.get(base_line.id) or Warranty.search([
                ('sale_order_line_id', '=', base_line.id),
                ('sale_order_id', '=', sale_id.id),
                ('warranty_kind', 'in', ['standard', False]),
            ], order='id asc').ids

            used_base_ids = set(existing_ext.mapped('base_warranty_id').ids)
            available_base_ids = [bid for bid in base_warr_ids if bid not in used_base_ids]

            tmpl = line.product_id.product_tmpl_id
            for i in range(max(0, needed_ext)):
                base_warr = Warranty.browse(available_base_ids[i]) if i < len(available_base_ids) else False
                start = base_warr.end_date if base_warr and base_warr.end_date else (sale_id.date_order or fields.Datetime.now())

                if tmpl.duration == "days":
                    end = start + datetime.timedelta(days=tmpl.period)
                elif tmpl.duration == "months":
                    end = start + relativedelta(months=+tmpl.period)
                elif tmpl.duration == "years":
                    end = start + relativedelta(years=+tmpl.period)
                else:
                    end = False

                vals_ext = {
                    "partner_id": sale_id.partner_id.id,
                    "product_id": tmpl.id,  # SKU servicio
                    "start_date": start if end else False,
                    "end_date": end if end else False,
                    "company_id": sale_id.company_id.id,
                    "qty": 1,
                    "warranty_date": date.today(),
                    "sale_order_id": sale_id.id,
                    "sale_order_line_id": line.id,
                    "warranty_kind": "extended",
                    "base_warranty_id": base_warr.id if base_warr else False,
                }
                Warranty.sudo().create(vals_ext)

        all_warr = Warranty.search([('sale_order_id', '=', sale_id.id)]).ids
        sale_id.warranty_ids = [(6, 0, all_warr)]

    def action_confirm(self):
        for order in self:
            has_warranty_lines = any(
                getattr(l, 'is_warranty', False) and l.product_uom_qty > 0
                for l in order.order_line
            )
            if has_warranty_lines and not self.env.context.get('serials_done'):
                return {
                    'name': _('Asignar serial(es)'),
                    'type': 'ir.actions.act_window',
                    'res_model': 'sr.warranty.serial.wizard',
                    'view_mode': 'form',
                    'target': 'new',
                    'context': {'default_sale_id': order.id},
                }

        for order in self:
            for line in order.order_line:
                if getattr(line, 'is_warranty', False) and line.price_unit <= 0.0:
                    tmpl = line.product_id.product_tmpl_id
                    percent = float(getattr(tmpl, 'warranty_percent', 0.0) or 0.0) / 100.0
                    base_line = getattr(line, 'warranty_base_line_id', False)
                    base_price = 0.0
                    if base_line:
                        base_price = base_line.price_unit or base_line.product_id.list_price or 0.0
                    elif getattr(tmpl, 'related_base_product_id', False):
                        base_price = tmpl.related_base_product_id.list_price or 0.0
                    if base_price and percent:
                        line.price_unit = round(base_price * percent, 2)

        res = super().action_confirm()
        for order in self:
            self.create_warranty_records(order)
        return res


class SaleOrderLine(models.Model):
    _inherit = "sale.order.line"

    warranty_id = fields.Many2one("sr.product.warranty")

    def _get_warranty_percent(self):
        """Lee únicamente el % definido en el product.template del servicio de garantía."""
        self.ensure_one()
        tmpl = self.product_id.product_tmpl_id
        return float(getattr(tmpl, 'warranty_percent', 0.0) or 0.0)

    @api.onchange('product_id')
    def _onchange_product_set_extended_price(self):
        if not self.product_id:
            return
        if not getattr(self, 'is_warranty', False):
            return
        percent = self._get_warranty_percent()
        if not percent:
            return

        base_line = getattr(self, 'warranty_base_line_id', False)
        if base_line:
            base_price = base_line.price_unit or base_line.product_id.list_price or 0.0
        else:
            related_base = getattr(self.product_id.product_tmpl_id, 'related_base_product_id', False)
            base_price = related_base.list_price if related_base else 0.0
        if base_price:
            decimals = (self.order_id.currency_id.decimal_places or 2) if self.order_id else 2
            self.price_unit = round(base_price * (percent / 100.0), decimals)

    @api.onchange('product_uom_qty')
    def _onchange_warranty_qty_reprice(self):
        for line in self:
            if not line.product_id:
                continue

            if not getattr(line, 'is_warranty', False):
                continue

            percent = float(line._get_warranty_percent() or 0.0)
            if percent <= 0.0:
                line.price_unit = 0.0
                continue

            base_line = getattr(line, 'warranty_base_line_id', False)
            if base_line:
                base_price = base_line.price_unit or base_line.product_id.list_price or 0.0
            else:
                if line.order_id:
                    candidates = line.order_id.order_line.filtered(
                        lambda l: l.id != line.id and not getattr(l, 'is_warranty', False) and l.product_id
                    )
                    base_line = candidates[:1] if candidates else False
                else:
                    base_line = False
                base_price = (base_line.price_unit if base_line else 0.0) or \
                             (getattr(line.product_id.product_tmpl_id, 'related_base_product_id', False) and
                              line.product_id.product_tmpl_id.related_base_product_id.list_price) or 0.0

            decimals = (line.order_id.currency_id.decimal_places or 2) if line.order_id else 2
            line.price_unit = round(base_price * (percent / 100.0), decimals)

    @api.onchange('price_unit')
    def _onchange_base_price_propagate_to_warranty(self):
        """Si esta es línea BASE y cambia su precio, actualizar el price_unit de su(s) garantía(s)."""
        for base in self:
            if getattr(base, 'is_warranty', False):
                continue
            if not base.order_id or base.display_type:
                continue

            warr_lines = base.order_id.order_line.filtered(
                lambda l: getattr(l, 'is_warranty', False) and l.warranty_base_line_id.id == base.id
            )
            if not warr_lines:
                continue
            decimals = (base.order_id.currency_id.decimal_places or 2)
            for w in warr_lines:
                percent = (w._get_warranty_percent() or 0.0) / 100.0
                w.price_unit = round((base.price_unit or 0.0) * percent, decimals)
