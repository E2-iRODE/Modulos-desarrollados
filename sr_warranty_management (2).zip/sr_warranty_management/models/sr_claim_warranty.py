# -*- coding: utf-8 -*-

from odoo import api, fields, models, _
from odoo.exceptions import ValidationError


class srClaimWarranty(models.Model):
    _name = "sr.claim.warranty"
    _description = "Reclamo de Garantía"
    _rec_name = "name"
    _inherit = ["portal.mixin", "mail.thread", "mail.activity.mixin", "utm.mixin"]

    name = fields.Char("Nombre")

    issue = fields.Text("Descripción del Problema")
    date = fields.Date("Fecha del Reclamo", default=fields.Date.context_today)
    state = fields.Selection(
        [
            ("draft", "Borrador"),
            ("review", "En Revisión"),
            ("repair", "En Reparación"),
            ("done", "Finalizado"),
            ("reject", "Rechazado"),
        ],
        string="Estado del Reclamo",
        default="review",
        tracking=True,
    )
    reason = fields.Text("Motivo del Rechazo")
    claim_warranty_parts_ids = fields.One2many(
        "sr.claim.warranty.parts", "claim_warranty_id"
    )

    partner_id = fields.Many2one("res.partner", "Cliente")
    phone = fields.Char("Teléfono", related="partner_id.phone")
    email = fields.Char("Correo Electrónico", related="partner_id.email")

    product_id = fields.Many2one("product.template", "Producto")
    product_ref_code = fields.Char("Código de Producto", related="product_id.default_code")
    product_barcode = fields.Char("Código de Barras", related="product_id.barcode")
    serial_number = fields.Char("Número de Serie")

    warranty_id = fields.Many2one(
        "sr.product.warranty",
        string="Garantía",
        required=True,
        index=True,
    )

    start_date = fields.Date("Fecha de Inicio de Garantía")
    end_date = fields.Date("Fecha de Fin de Garantía")
    warranty_state = fields.Selection(
        [("in_warranty", "En Garantía"), ("expired_warranty", "Garantía Vencida")],
        string="Estado de la Garantía",
    )
    warranty_sale_order_id = fields.Many2one("sale.order", "Pedido de Venta de la Garantía")
    warranty_count = fields.Integer("Cantidad de Garantías", compute="_get_warranty")

    sale_order_id = fields.Many2one("sale.order", "Pedido de Venta del Reclamo")
    sale_order_count = fields.Integer("Cantidad de Pedidos de Venta", compute="_get_claim_sale_order")
    is_order = fields.Boolean("¿Es Pedido?")

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if vals.get("name", "New") == "New":
                vals["name"] = self.env["ir.sequence"].next_by_code("sr.claim.warranty") or "New"

        records = super().create(vals_list)

        for rec in records:
            if rec.warranty_id and rec.warranty_id.state == "in_warranty":
                rec.warranty_id.state = "expired_warranty"

        return records

    @api.depends('warranty_id')
    def _get_warranty(self):
        for rec in self:
            rec.warranty_count = 1 if rec.warranty_id else 0

    def open_view_warranty_action(self):
        self.ensure_one()
        domain = [("id", "=", self.warranty_id.id)] if self.warranty_id else [("id", "=", 0)]
        return {
            "name": "Garantía",
            "type": "ir.actions.act_window",
            "view_mode": "list,form",
            "res_model": "sr.product.warranty",
            "views": [(False, "list"), (False, "form")],
            "domain": domain,
        }

    def claim_accept(self):
        self.state = "repair"
        self.is_order = True

    def claim_done(self):
        self.state = "done"

    def claim_refuse(self):
        action = self.env.ref("sr_warranty_management.sr_claim_refuse_reason_action").read()[0]
        return action

    def claim_parts_sale_order(self):
        order_lines = []
        if not self.claim_warranty_parts_ids:
            raise ValidationError(_("Por favor ingrese los detalles de las partes."))
        for line in self.claim_warranty_parts_ids:
            order_lines.append(
                (
                    0,
                    0,
                    {
                        "product_id": line.product_id.product_variant_id.id,
                        "product_uom_qty": line.qty,
                        "price_unit": 0.0,
                        "name": _("Reemplazo en Garantía (%s)") % self.name,
                    },
                )
            )
        sale_order = self.env["sale.order"].create(
            {
                "partner_id": self.partner_id.id,
                "claim_id": self.id,
                "order_line": order_lines,
                "is_warranty": True,
            }
        )
        if sale_order:
            self.sale_order_id = sale_order.id
            self.state = "done"
            self.is_order = False

    @api.depends('sale_order_id')
    def _get_claim_sale_order(self):
        Sale = self.env["sale.order"]
        for rec in self:
            rec.sale_order_count = Sale.search_count([("claim_id", "=", rec.id), ("is_warranty", "=", True)])

    def action_view_calim_sale_order(self):
        return {
            "name": "Pedidos de Venta",
            "type": "ir.actions.act_window",
            "view_mode": "list,form",
            "res_model": "sale.order",
            "views": [(False, "list"), (False, "form")],
            "domain": [("claim_id", "=", self.id), ("is_warranty", "=", True)],
        }

    def action_create_repair_order(self):
        self.ensure_one()

        product_variant = self.product_id.product_variant_id
        repair_order = self.env["repair.order"].create(
            {
                "partner_id": self.partner_id.id,
                "product_id": product_variant.id,
                "product_qty": 1.0,
            }
        )
        return {
            "name": "Orden de Reparación",
            "type": "ir.actions.act_window",
            "res_model": "repair.order",
            "res_id": repair_order.id,
            "view_mode": "form",
            "target": "current",
        }


class srClaimWarrantyParts(models.Model):
    _name = "sr.claim.warranty.parts"
    _description = "Partes de Reclamo de Garantía"

    claim_warranty_id = fields.Many2one("sr.claim.warranty")
    product_id = fields.Many2one("product.template", "Producto")
    qty = fields.Float("Cantidad", default=1)
