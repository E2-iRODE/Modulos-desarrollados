# -*- coding: utf-8 -*-

from odoo import fields, models, _


class srClaimRefuseReason(models.TransientModel):
    _name = "sr.claim.refuse.reason"
    _description = "Motivo de rechazo del reclamo"

    reason = fields.Text("Motivo de rechazo")

    def update_refuse_reason(self):
        active_id = self.env["sr.claim.warranty"].browse(
            self.env.context.get("active_id")
        )
        if active_id:
            active_id.reason = self.reason
            active_id.state = "reject"
