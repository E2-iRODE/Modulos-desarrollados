# -*- coding: utf-8 -*-

from odoo import fields, models, _
import datetime
from dateutil.relativedelta import relativedelta


class srRenewWarranty(models.TransientModel):
    _name = "sr.renew.warranty"
    _description = "Renovar Garantía"

    period = fields.Integer("Período de Garantía")
    duration = fields.Selection(
        [("days", "Días"), ("months", "Meses"), ("years", "Años")],
        default="days"
    )
    renew_cost = fields.Float("Costo de Renovación")

    def default_get(self, fields_list):
        """Autocalcula renew_cost = 10% del precio del producto base de la garantía activa."""
        res = super().default_get(fields_list)
        active_warranty = self.env['sr.product.warranty'].browse(
            self.env.context.get('active_id')
        )
        if active_warranty and active_warranty.product_id:
            base_price = active_warranty.product_id.list_price or 0.0
            res['renew_cost'] = round(base_price * 0.10, 2)
        return res

    def update_renew_warranty(self):
        invoice_obj = self.env['account.move']
        warranty_model = self.env['sr.product.warranty']
        active_warranty = warranty_model.browse(self.env.context.get("active_id"))

        if active_warranty and self.period > 0:
            
            active_warranty.sudo().write({
                "history_ids": [(0, 0, {
                    "warranty_id": active_warranty.id,
                    "partner_id": active_warranty.partner_id.id,
                    "product_id": active_warranty.product_id.id,
                    "serial_number": active_warranty.serial_number,
                    "start_date": active_warranty.start_date,
                    "end_date": active_warranty.end_date,
                    "renewal_cost": self.renew_cost,
                })]
            })

            start_date = active_warranty.end_date
            if self.duration == "days":
                end_date = start_date + datetime.timedelta(days=self.period)
            elif self.duration == "months":
                end_date = start_date + relativedelta(months=+self.period)
            elif self.duration == "years":
                end_date = start_date + relativedelta(years=+self.period)
            else:
                end_date = start_date

            
            new_warranty = warranty_model.create({
                "partner_id": active_warranty.partner_id.id,
                "product_id": active_warranty.product_id.id,
                "serial_number": active_warranty.serial_number,
                "qty": active_warranty.qty,
                "start_date": start_date,
                "end_date": end_date,
                "period": self.period,
                "duration": self.duration,
                "renewal_cost": self.renew_cost,
                "warranty_date": fields.Date.today(),
                "state": "in_warranty",
                "company_id": active_warranty.company_id.id,
                "warranty_kind": "extended",
                "base_warranty_id": active_warranty.id,
            })

            
            product = active_warranty.product_id.product_variant_id
            account_id = product.property_account_income_id or product.categ_id.property_account_income_categ_id

            invoice = invoice_obj.create({
                "warranty_id": new_warranty.id,
                "partner_id": new_warranty.partner_id.id,
                "move_type": "out_invoice",
                "is_warranty": True,
                "invoice_line_ids": [(0, 0, {
                    "product_id": product.id,
                    "quantity": 1,
                    "price_unit": self.renew_cost,
                    "account_id": account_id.id,
                    "name": _("Renovación de garantía (10%% de %s)") % (
                        active_warranty.product_id.display_name,
                    ),
                })]
            })

            new_warranty.invoice_id = invoice.id

