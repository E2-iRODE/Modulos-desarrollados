from odoo import models, fields

class SrExtendedWarrantyWizardLine(models.TransientModel):
    _name = 'sr.extended.warranty.wizard.line'
    _description = 'Extended Warranty Wizard Line'

    wizard_id = fields.Many2one('sr.extended.warranty.wizard')
    sale_line_id = fields.Many2one('sale.order.line')
    product_id = fields.Many2one('product.product')
    qty_ordered = fields.Float()
    qty_current = fields.Float()
    qty_desired = fields.Float()
