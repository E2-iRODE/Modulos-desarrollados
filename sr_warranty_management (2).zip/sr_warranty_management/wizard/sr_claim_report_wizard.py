# -*- coding: utf-8 -*-

from odoo import fields, api, models, _
from datetime import date
from odoo.exceptions import ValidationError


class srClaimReportWizard(models.TransientModel):
    _name = "sr.claim.report.wizard"
    _description = "Reporte de Reclamos"

    start_date = fields.Date("Fecha inicio")
    end_date = fields.Date("Fecha fin")
    state = fields.Selection(
        [
            ("review", "En revisión"),
            ("repair", "En reparación"),
            ("done", "Completado"),
            ("reject", "Rechazado"),
        ],
        string="Estado del reclamo",
    )

    @api.onchange("start_date")
    def _end_date_onchange(self):
        if self.end_date and self.start_date > self.end_date:
            raise ValidationError(_("La fecha de inicio no puede ser mayor que la fecha fin."))

    @api.onchange("end_date")
    def _start_date_onchange(self):
        if self.start_date and self.start_date > self.end_date:
            raise ValidationError(_("La fecha fin no puede ser menor que la fecha de inicio."))

    def print_pdf_report(self):
        data = {}
        return self.env.ref(
            "sr_warranty_management.sr_claim_warranty_report_action"
        ).report_action(None, data=data)
