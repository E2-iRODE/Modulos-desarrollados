# -*- coding: utf-8 -*-

from odoo import fields, api, models, _
from datetime import date
from odoo.exceptions import ValidationError


class srWarrantyReportWizard(models.TransientModel):
    _name = "sr.warranty.report.wizard"
    _description = "Reporte de Garantías"

    start_date = fields.Date("Fecha inicio")
    end_date = fields.Date("Fecha fin")
    state = fields.Selection(
        [
            ("in_warranty", "En garantía"),
            ("expired_warranty", "Garantía vencida"),
        ],
        string="Estado de garantía",
    )

    @api.onchange("start_date")
    def _end_date_onchange(self):
        if self.end_date and self.start_date > self.end_date:
            raise ValidationError(_("La fecha de inicio no puede ser mayor que la fecha fin."))

    @api.onchange("end_date")
    def _start_date_onchange(self):
        if self.start_date and self.start_date > self.end_date:
            raise ValidationError(_("La fecha fin no puede ser menor que la fecha de inicio."))

    def print_pdf_report(self):
        data = {}
        return self.env.ref(
            "sr_warranty_management.sr_product_warranty_report_action"
        ).report_action(None, data=data)
