from odoo import models, fields, api, _
from odoo.exceptions import UserError

class SrExtendedWarrantyWizard(models.TransientModel):
    _name = 'sr.extended.warranty.wizard'
    _description = 'Extended Warranty Wizard'

    sale_order_id = fields.Many2one('sale.order', required=True)
    line_ids = fields.One2many('sr.extended.warranty.wizard.line', 'wizard_id')

    def action_apply(self):
        for line in self.line_ids:
            base_line = line.sale_line_id
            if not base_line or not base_line.order_id:
                continue

            tmpl = base_line.product_id.product_tmpl_id
            service_product = getattr(tmpl, 'warranty_service_product_id', False)

            if line.qty_desired and not service_product:
                raise UserError(_('El producto %s no tiene configurado un servicio de garantía extendida.') % base_line.product_id.display_name)

            existing = base_line.order_id.order_line.filtered(
                lambda l: getattr(l, 'is_warranty', False) and l.warranty_base_line_id.id == base_line.id
            )

            if line.qty_desired <= 0:
                if existing:
                    existing.unlink()
                continue

            percent = float(getattr(service_product.product_tmpl_id, 'warranty_percent', 0.0) or 0.0)
            base_price = base_line.price_unit or base_line.product_id.list_price or 0.0
            currency = base_line.order_id.currency_id
            decimals = currency.decimal_places or 2
            price = round(base_price * (percent / 100.0), decimals) if percent and base_price else 0.0

            base_label = base_line.product_id.display_name or base_line.name or ''
            service_name = service_product.display_name
            description = '%s — Garantía extendida de %s%% sobre %s' % (service_name, percent, base_label)

            if existing:
                wl = existing[0]
                wl.product_uom_qty = line.qty_desired
                wl.price_unit = price
                wl.name = description
            else:
                self.env['sale.order.line'].create({
                    'order_id': base_line.order_id.id,
                    'product_id': service_product.id,
                    'product_uom_qty': line.qty_desired,
                    'price_unit': price,
                    'is_warranty': True,
                    'warranty_base_line_id': base_line.id,
                    'name': description,
                })

        return {'type': 'ir.actions.act_window_close'}
