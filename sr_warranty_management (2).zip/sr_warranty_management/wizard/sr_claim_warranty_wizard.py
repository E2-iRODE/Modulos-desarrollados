# -*- coding: utf-8 -*-

from odoo import fields, models, _
from datetime import date


class srClaimWarrantyWizard(models.TransientModel):
    _name = "sr.claim.warranty.wizard"
    _description = "Reclamo de Garantía"

    issue = fields.Text("Descripción del Problema")

    def create_claim_warranty(self):
        active_id = self.env["sr.product.warranty"].browse(
            self.env.context.get("active_id")
        )
        if active_id:
            claim_id = (
                self.env["sr.claim.warranty"]
                .sudo()
                .create(
                    {
                        "issue": self.issue,
                        "date": date.today(),
                        "warranty_id": active_id.id,
                        "partner_id": active_id.partner_id.id,
                        "product_id": active_id.product_id.id,
                        "serial_number": active_id.serial_number,
                        "start_date": active_id.start_date,
                        "end_date": active_id.end_date,
                        "warranty_state": active_id.state,
                        "warranty_sale_order_id": active_id.sale_order_id.id,
                        "state": "review",
                    }
                )
            )
            if claim_id:
                active_id.claim_id = claim_id.id
