# -*- coding: utf-8 -*-

{
    "name": "Gestión de Garantías y Reclamos de Productos",
      "version": "18.0.1.0.0",
    "category": "Sales/Sales",
    "summary": "Gestión de garantías y reclamos de productos, seguimiento de periodos, procesamiento de reclamos, módulo de garantía en Odoo",
    "description": """
Gestión de Garantías de Productos
Gestión de Reclamos de Garantía
Seguimiento de periodos de garantía
Procesamiento de reclamos de garantía
Módulo de gestión de garantías y reclamos en Odoo
    """,
    "author": "IRODE TECHNOLOGY",
    "website": "https://www.irodetech.com",
    "license": "OPL-1",
    "depends": [
        "base",
        "stock",
        "sale_management",
        "account",
        "repair",
        "point_of_sale",
    ],
    "data": [
        "security/ir.model.access.csv",
        "security/sr_warranty_config_group.xml",
        "data/ir_sequence_data.xml",
      
        "views/sr_product_warranty_view.xml",
        "views/inherited_product_template.xml",
        "views/inherited_sale_order_view.xml",
        "views/inherited_pos_order_view.xml",
        "views/sr_warranty_configuration_view.xml",
        "views/sr_claim_warranty_view.xml",
        "views/sr_warranty_report.xml",
        "views/sr_claim_report.xml",
        "views/inherited_product_view.xml",
        "views/inherited_account_move_view.xml",
        "wizard/sr_renew_warranty_view.xml",
        "wizard/sr_claim_warranty_wizard_view.xml",
        "wizard/sr_claim_refuse_reason_view.xml",
        "wizard/sr_warranty_report_wizard_view.xml",
        "wizard/sr_claim_report_wizard_view.xml",
        "views/sr_reporting_menu_view.xml",
        "wizard/sr_extended_warranty_wizard_view.xml",
        "views/sr_extended_warranty_action.xml",
        "report/sr_warranty_report_template.xml",
        "report/sr_report_warranty_templates.xml",
        "report/sr_warranty_report_action.xml",
        "report/sr_claim_report_template.xml",
        "report/sr_report_claim_templates.xml",
        "report/sr_claim_report_action.xml",
          "data/ir_cron_warranty_expired.xml",
        "data/ir_cron_warranty_expire_notification.xml",
    ],
    "assets": {
        "point_of_sale._assets_pos": [
            "sr_warranty_management/static/src/js/pos_extended_warranty.js",
            "sr_warranty_management/static/src/js/pos_warranty_orderline_patch.js",
            "sr_warranty_management/static/src/xml/pos_extended_warranty.xml",
            "sr_warranty_management/static/src/css/pos_extended_warranty.css",
        ],
    },
    "images": ["static/description/icon.png"],
    "application": True,
    "installable": True,
    "auto_install": False,
}