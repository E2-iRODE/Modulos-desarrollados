/** @odoo-module **/

import { _t } from "@web/core/l10n/translation";
import { useService } from "@web/core/utils/hooks";
import { Component, useState } from "@odoo/owl";
import { usePos } from "@point_of_sale/app/store/pos_hook";
import { ProductScreen } from "@point_of_sale/app/screens/product_screen/product_screen";
import { ErrorPopup } from "@point_of_sale/app/errors/popups/error_popup";
import { AbstractAwaitablePopup } from "@point_of_sale/app/popup/abstract_awaitable_popup";

function toNumber(v) {
    const n = Number(v);
    return Number.isFinite(n) ? n : 0;
}

function roundToCurrency(pos, value) {
    const decimals = (pos.currency && pos.currency.decimals) || 2;
    return Number(toNumber(value).toFixed(decimals));
}

function isWarrantyLine(line) {
    return !!(line && line.sr_warranty_base_line_uuid);
}

function parseSerials(raw) {
    const txt = (raw || "").trim();
    if (!txt) return [];
    return txt
        .split(/[\n,]+/g)
        .map((s) => s.trim())
        .filter((s) => !!s);
}

function normalizeQty(n) {
    return Math.max(0, Math.floor(toNumber(n) || 0));
}

function findWarrantyLineForBaseUuid(order, baseUuid) {
    return order
        .get_orderlines()
        .find((l) => l && isWarrantyLine(l) && l.sr_warranty_base_line_uuid === baseUuid) || null;
}

function getOrCreateWarrantyLine(order, warrantyProduct, baseLine, percent, qty, warrantyUnit) {
    const existing = findWarrantyLineForBaseUuid(order, baseLine.uuid);
    if (existing) {
        const prevQty = normalizeQty(existing.quantity);

        existing.sr_warranty_percent = percent;
        existing.sr_warranty_base_product_name =
            baseLine.get_full_product_name?.() ||
            baseLine.product.display_name ||
            baseLine.product.name ||
            "";
        existing.price_type = "manual";
        existing.price_manually_set = true;

        if (typeof existing.set_unit_price === "function") {
            existing.set_unit_price(warrantyUnit);
        } else {
            existing.price = warrantyUnit;
        }

        if (typeof existing.set_quantity === "function") {
            existing.set_quantity(qty);
        } else {
            existing.quantity = qty;
        }

        if (prevQty !== qty) {
            existing.sr_warranty_serial = false;
        }

        return existing;
    }

    order.add_product(warrantyProduct, {
        quantity: qty,
        price: warrantyUnit,
        price_manually_set: true,
    });

    const lines = order.get_orderlines();
    const created =
        [...lines].reverse().find((l) => l && l.product && l.product.id === warrantyProduct.id) || null;

    if (!created) return null;

    created.sr_warranty_base_line_uuid = baseLine.uuid;
    created.sr_warranty_percent = percent;
    created.sr_warranty_serial = false;
    created.sr_warranty_base_product_name =
        baseLine.get_full_product_name?.() ||
        baseLine.product.display_name ||
        baseLine.product.name ||
        "";
    created.price_type = "manual";
    created.price_manually_set = true;

    if (typeof created.set_unit_price === "function") {
        created.set_unit_price(warrantyUnit);
    } else {
        created.price = warrantyUnit;
    }

    return created;
}

function removeWarrantyLine(order, baseUuid) {
    const line = findWarrantyLineForBaseUuid(order, baseUuid);
    if (line) {
        order.removeOrderline(line);
        return true;
    }
    return false;
}

function buildSerialRows(order) {
    const rows = [];
    const wlines = order.get_orderlines().filter((l) => l && isWarrantyLine(l) && normalizeQty(l.quantity) > 0);

    for (const wline of wlines) {
        const qty = normalizeQty(wline.quantity);
        const existing = parseSerials(wline.sr_warranty_serial);
        const base = order.get_orderlines().find((l) => l && l.uuid === wline.sr_warranty_base_line_uuid) || null;

        const baseName =
            (base && (base.get_full_product_name?.() || base.product?.display_name || base.product?.name)) ||
            wline.sr_warranty_base_product_name ||
            "";

        for (let i = 0; i < qty; i++) {
            rows.push({
                id: `${wline.uuid}:${i}`,
                base_name: baseName,
                serial: existing[i] || "",
            });
        }
    }

    return rows;
}

function applySerialRows(order, serialRows) {
    const byLine = new Map();

    for (const r of serialRows || []) {
        const [wUuid, idxStr] = String(r.id || "").split(":");
        const idx = Number(idxStr || 0);
        if (!wUuid || Number.isNaN(idx)) continue;
        if (!byLine.has(wUuid)) byLine.set(wUuid, []);
        byLine.get(wUuid)[idx] = (r.serial || "").trim();
    }

    for (const [wUuid, arr] of byLine.entries()) {
        const line = order.get_orderlines().find((l) => l && l.uuid === wUuid);
        if (!line) continue;

        const qty = normalizeQty(line.quantity);
        const serials = (arr || []).slice(0, qty).map((s) => (s || "").trim());
        if (serials.some((s) => !s) || new Set(serials).size !== serials.length) {
            line.sr_warranty_serial = false;
            continue;
        }
        line.sr_warranty_serial = serials.join(",");
    }
}

export class SrWarrantyQtyPopup extends AbstractAwaitablePopup {
    static template = "sr_warranty_management.SrWarrantyQtyPopup";

    setup() {
        super.setup();
        this.state = useState({
            rows: (this.props.rows || []).map((r) => ({
                base_uuid: r.base_uuid,
                base_name: r.base_name,
                base_qty: normalizeQty(r.base_qty),
                desired_qty: normalizeQty(r.desired_qty),
            })),
        });
    }

    setDesired(row, ev) {
        const val = normalizeQty(ev?.target?.value);
        row.desired_qty = Math.min(val, row.base_qty);
    }

    getPayload() {
        return this.state.rows.map((r) => ({
            base_uuid: r.base_uuid,
            desired_qty: normalizeQty(r.desired_qty),
        }));
    }
}

export class SrWarrantySerialsPopup extends AbstractAwaitablePopup {
    static template = "sr_warranty_management.SrWarrantySerialsPopup";

    setup() {
        super.setup();
        const rows = this.props.rows || [];
        this.state = useState({
            rows: rows.map((r) => ({
                id: r.id,
                base_name: r.base_name,
                serial: (r.serial || "").trim(),
            })),
        });
    }

    updateSerial(row, ev) {
        row.serial = (ev?.target?.value || "").trim();
    }

    getPayload() {
        return this.state.rows.map((r) => ({
            id: r.id,
            serial: (r.serial || "").trim(),
        }));
    }
}

export class SrWarrantyButton extends Component {
    static template = "sr_warranty_management.SrWarrantyButton";

    setup() {
        this.pos = usePos();
        this.popup = useService("popup");
        this.orm = useService("orm");
    }

    async _fetchTemplateWarrantyConfig(productId) {
        const prodData = await this.orm.call("product.product", "search_read", [
            [["id", "=", productId]],
            ["product_tmpl_id"],
        ]);
        if (!prodData || !prodData.length || !prodData[0].product_tmpl_id) return null;

        const baseTmplId = prodData[0].product_tmpl_id[0];
        const tpl = await this.orm.call("product.template", "read", [
            [baseTmplId],
            ["pos_extended_warranty_enabled", "warranty_service_product_id", "warranty_percent"],
        ]);
        const baseTmpl = tpl && tpl[0] ? tpl[0] : {};
        return { baseTmplId, baseTmpl };
    }

    async onClick() {
        const order = this.pos.get_order();
        if (!order) {
            await this.popup.add(ErrorPopup, {
                title: _t("Sin pedido"),
                body: _t("No hay un pedido activo en el TPV."),
            });
            return;
        }

        const baseLines = order
            .get_orderlines()
            .filter((l) => l && l.product && !isWarrantyLine(l) && normalizeQty(l.quantity) > 0);

        if (!baseLines.length) {
            await this.popup.add(ErrorPopup, {
                title: _t("Sin productos"),
                body: _t("Agrega productos para poder asignar garantía extendida."),
            });
            return;
        }

        let percentByBaseUuid = {};
        let enabledByBaseUuid = {};
        let serviceIdByBaseUuid = {};

        for (const line of baseLines) {
            try {
                const cfg = await this._fetchTemplateWarrantyConfig(line.product.id);
                if (!cfg || !cfg.baseTmpl) continue;

                const baseTmpl = cfg.baseTmpl;
                enabledByBaseUuid[line.uuid] = !!baseTmpl.pos_extended_warranty_enabled;

                const serviceInfo = baseTmpl.warranty_service_product_id || [];
                const serviceId = serviceInfo[0] || false;
                serviceIdByBaseUuid[line.uuid] = serviceId;

                const percent = toNumber(baseTmpl.warranty_percent || 0);
                percentByBaseUuid[line.uuid] = percent;
            } catch (_e) {
                enabledByBaseUuid[line.uuid] = false;
            }
        }

        const eligible = baseLines.filter((l) => {
            const enabled = !!enabledByBaseUuid[l.uuid];
            const serviceId = serviceIdByBaseUuid[l.uuid];
            const percent = toNumber(percentByBaseUuid[l.uuid] || 0);
            const loaded = serviceId ? !!this.pos.db.get_product_by_id(serviceId) : false;
            return enabled && serviceId && loaded && percent > 0;
        });

        if (!eligible.length) {
            await this.popup.add(ErrorPopup, {
                title: _t("No aplica"),
                body: _t("No hay productos elegibles con garantía extendida habilitada y configurada."),
            });
            return;
        }

        const rows = eligible.map((l) => {
            const existing = findWarrantyLineForBaseUuid(order, l.uuid);
            return {
                base_uuid: l.uuid,
                base_name: l.get_full_product_name?.() || l.product.display_name || l.product.name || "",
                base_qty: normalizeQty(l.quantity),
                desired_qty: existing ? normalizeQty(existing.quantity) : 0,
            };
        });

        const { confirmed, payload } = await this.popup.add(SrWarrantyQtyPopup, {
            title: _t("Garantías Extendidas"),
            rows,
        });

        if (!confirmed) return;

        const desiredMap = new Map((payload || []).map((p) => [p.base_uuid, normalizeQty(p.desired_qty)]));

        for (const baseLine of eligible) {
            const desiredQty = Math.min(desiredMap.get(baseLine.uuid) || 0, normalizeQty(baseLine.quantity));
            const serviceId = serviceIdByBaseUuid[baseLine.uuid];
            const percent = toNumber(percentByBaseUuid[baseLine.uuid] || 0);

            if (!serviceId || percent <= 0) continue;
            const warrantyProduct = this.pos.db.get_product_by_id(serviceId);
            if (!warrantyProduct) continue;

            const baseUnitPrice =
                typeof baseLine.get_unit_price === "function"
                    ? toNumber(baseLine.get_unit_price())
                    : toNumber(baseLine.price || 0);

            const warrantyUnit = roundToCurrency(this.pos, baseUnitPrice * (percent / 100.0));

            if (desiredQty <= 0) {
                removeWarrantyLine(order, baseLine.uuid);
                continue;
            }

            const wline = getOrCreateWarrantyLine(order, warrantyProduct, baseLine, percent, desiredQty, warrantyUnit);
            if (!wline) {
                await this.popup.add(ErrorPopup, {
                    title: _t("Error"),
                    body: _t("No se pudo crear/actualizar la línea de garantía en el pedido."),
                });
                return;
            }
        }

        const serialRows = buildSerialRows(order);
        if (!serialRows.length) return;

        const { confirmed: sConfirmed, payload: sPayload } = await this.popup.add(SrWarrantySerialsPopup, {
            title: _t("Asignar serial(es)"),
            rows: serialRows,
        });

        if (!sConfirmed) return;

        const merged = serialRows.map((r) => {
            const u = (sPayload || []).find((x) => x.id === r.id);
            return { ...r, serial: u ? (u.serial || "").trim() : (r.serial || "").trim() };
        });

        const serialsOnly = merged.map((r) => (r.serial || "").trim());
        if (serialsOnly.some((s) => !s) || new Set(serialsOnly).size !== serialsOnly.length) {
            await this.popup.add(ErrorPopup, {
                title: _t("Seriales inválidos"),
                body: _t("Debes ingresar seriales para todas las garantías y no pueden repetirse."),
            });
            return;
        }

        applySerialRows(order, merged.map((r) => ({ id: r.id, serial: r.serial })));
    }
}

ProductScreen.addControlButton({
    component: SrWarrantyButton,
    position: ["after", "OrderlineCustomerNoteButton"],
    condition() {
        const order = this.pos.get_order();
        return !!order;
    },
});
