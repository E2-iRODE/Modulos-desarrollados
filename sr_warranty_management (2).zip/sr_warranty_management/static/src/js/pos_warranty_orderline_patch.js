/** @odoo-module **/

import { patch } from "@web/core/utils/patch";
import { Order, Orderline } from "@point_of_sale/app/store/models";

function toNumber(v) {
    const n = Number(v);
    return Number.isFinite(n) ? n : 0;
}

function roundToCurrency(pos, value) {
    const decimals = (pos.currency && pos.currency.decimals) || 2;
    return Number(toNumber(value).toFixed(decimals));
}

function isWarrantyLine(line) {
    return !!(line && line.sr_warranty_base_line_uuid);
}

function getBaseLine(order, warrantyLine) {
    const baseUuid = warrantyLine && warrantyLine.sr_warranty_base_line_uuid;
    if (!baseUuid) return null;
    return order.get_orderlines().find((l) => l && l.uuid === baseUuid) || null;
}

function parseSerials(raw) {
    const txt = (raw || "").trim();
    if (!txt) return [];
    return txt
        .split(/[\n,]+/g)
        .map((s) => s.trim())
        .filter((s) => !!s);
}

function computeWarrantyUnit(order, warrantyLine) {
    const percent = toNumber(warrantyLine && warrantyLine.sr_warranty_percent);
    if (percent <= 0) return 0;

    const base = getBaseLine(order, warrantyLine);
    if (!base) return 0;

    const baseUnit =
        typeof base.get_unit_price === "function"
            ? toNumber(base.get_unit_price())
            : toNumber(base.price || 0);
    if (baseUnit <= 0) return 0;

    return roundToCurrency(order.pos, baseUnit * (percent / 100.0));
}

function normalizeQty(n) {
    return Math.max(0, Math.floor(toNumber(n) || 0));
}

function enforceWarrantyLines(order) {
    const lines = order.get_orderlines();
    for (const l of lines) {
        if (!isWarrantyLine(l)) continue;

        const unit = computeWarrantyUnit(order, l);
        if (unit <= 0) continue;

        l.price_type = "manual";
        l.price_manually_set = true;

        if (typeof l.set_unit_price === "function") {
            l.set_unit_price(unit);
        } else {
            l.price = unit;
        }

        const qty = normalizeQty(l.quantity);
        const serials = parseSerials(l.sr_warranty_serial);
        if (serials.length !== qty) {
            l.sr_warranty_serial = false;
        }
    }
}

function scheduleEnforce(order) {
    if (!order) return;
    if (order.__srWarrantyScheduled) return;
    order.__srWarrantyScheduled = true;

    const run = () => {
        order.__srWarrantyScheduled = false;
        enforceWarrantyLines(order);
    };

    Promise.resolve().then(run);
    setTimeout(run, 0);
    setTimeout(run, 50);
    if (typeof requestAnimationFrame === "function") requestAnimationFrame(run);
}

patch(Orderline.prototype, {
    export_as_JSON() {
        const json = super.export_as_JSON(...arguments);
        json.sr_warranty_base_line_uuid = this.sr_warranty_base_line_uuid || false;
        json.sr_warranty_percent = this.sr_warranty_percent || false;
        json.sr_warranty_base_product_name = this.sr_warranty_base_product_name || false;
        json.sr_warranty_serial = this.sr_warranty_serial || false;
        return json;
    },
    init_from_JSON(json) {
        super.init_from_JSON(...arguments);
        this.sr_warranty_base_line_uuid = json.sr_warranty_base_line_uuid || false;
        this.sr_warranty_percent = json.sr_warranty_percent || false;
        this.sr_warranty_base_product_name = json.sr_warranty_base_product_name || false;
        this.sr_warranty_serial = json.sr_warranty_serial || false;
        if (this.sr_warranty_base_line_uuid) {
            this.price_type = "manual";
            this.price_manually_set = true;
        }
    },
    set_unit_price(price) {
        const res = super.set_unit_price(...arguments);
        if (this.order && isWarrantyLine(this)) {
            this.price_type = "manual";
            this.price_manually_set = true;
        }
        return res;
    },
    get_full_product_name() {
        const original = super.get_full_product_name(...arguments);

        if (!this.order || !isWarrantyLine(this)) {
            return original;
        }

        const percent = toNumber(this.sr_warranty_percent || 0);
        const percentTxt = percent > 0 ? ` (${percent}%)` : "";

        const base = getBaseLine(this.order, this) || null;

        const baseName =
            (base && (base.get_full_product_name?.() || base.product?.display_name || base.product?.name)) ||
            this.sr_warranty_base_product_name ||
            null;

        if (!baseName) return `${original}${percentTxt}`;
        return `${original}${percentTxt} — sobre ${baseName}`;
    },
});

patch(Order.prototype, {
    set_partner(partner) {
        const res = super.set_partner(...arguments);
        scheduleEnforce(this);
        return res;
    },
    set_pricelist(pricelist) {
        const res = super.set_pricelist(...arguments);
        scheduleEnforce(this);
        return res;
    },
    updatePricelistAndFiscalPosition(newPartner) {
        const res = super.updatePricelistAndFiscalPosition(...arguments);
        scheduleEnforce(this);
        return res;
    },
});
