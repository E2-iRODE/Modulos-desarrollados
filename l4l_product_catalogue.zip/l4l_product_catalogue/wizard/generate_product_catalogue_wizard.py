# -*- coding: utf-8 -*-
#
#    OpenERP, Open Source Management Solution
#    Copyright (C) 2023 Leap4Logic Solutions PVT LTD
#    Email : sales@leap4logic.com
#################################################

from odoo import models, fields, api, _
from odoo.exceptions import ValidationError
from odoo.http import request
import base64


class GenerateLeapProductCatalogue(models.TransientModel):
    _name = 'generate.leap.product.catalogue'
    _description = 'Wizard For Generate Product Catalogue'
    _rec_name = 'name'

    name = fields.Char('Nombre Catalogo', default="Catalogo Productos", size=20)
    catalogue_type = fields.Selection([('product', 'Producto'), ('category', 'Categoria'),('marca', 'Marca')], string='Filtra Producto',
                                    default='product')
    company_id = fields.Many2one(comodel_name='res.company', required=True, default=lambda self: self.env.company, ondelete="restrict", string="Compañia")
    currency_id = fields.Many2one(comodel_name='res.currency', default=lambda self: self.env.company.currency_id.id,
                                  ondelete="restrict", string="Divisa")
    
    product_ids = fields.Many2many('product.product', string="Productos",domain="['|', ('company_id', '=', False), ('company_id', '=', company_id)]" )
    category_ids = fields.Many2many('product.category', string="Categorias")
    antiguedad= fields.Selection(selection=lambda self: self._get_categoria_producto_options(), string='Antiguedad')
    marca_ids = fields.Many2many('x_marcas', string="Marcas")
    exclude_product_ids = fields.Many2many(
        'product.product',
        'generate_catalogue_exclude_product_rel',
        'wizard_id', 'product_id',
        string="Excluir Productos",
        domain="['|', ('company_id', '=', False), ('company_id', '=', company_id)]",
        help="Productos que NO aparecerán en el catálogo generado"
    )
    
    fecha_inicio=fields.Date(string="DE: ")
    fecha_fin=fields.Date(string="A: ")
    warehouse_ids = fields.Many2many(
        'stock.warehouse', 
        help="Selecciona uno o más almacenes para filtrar el stock"
    )

    image_size = fields.Selection([('small', 'Pequena'), ('medium', 'Mediana'), ('large', 'Grande')], string='Tamaño Imagen',
                                  default='small')
    card_size = fields.Selection([('small', 'Pequena'), ('medium', 'Mediana'), ('large', 'Grande')], string='Tamaño Tarjeta',
                                  default='small')


    pricelist_id = fields.Many2one(comodel_name='product.pricelist', string="Lista de Precios", check_company=True,
                                   ondelete="restrict")
    

    show_product_link = fields.Boolean(string='Link Producto', default=True)
    show_image = fields.Boolean(string='Imagen', default=True)
    show_internal_reference = fields.Boolean(string='Referencia Interna', default=True)
    show_category = fields.Boolean(string='Imprimir Categoria', default=True)
    show_uom = fields.Boolean(string='UOM', default=True)
    show_price = fields.Boolean(string='Precio', default=True)
    show_description = fields.Boolean(string='Descripcion', default=True)
    description_fields = fields.Many2one('ir.model.fields', domain="[('model_id', '=', 'product.product'), ('ttype', 'in', ['char', 'text'])]", string='Descripcion Campo', help='Choose the product description field')
    catalogue_style = fields.Selection(
        [('style_1', 'Estilo 1'), ('style_2', 'Estilo 2'), ('style_3', 'Estilo 3'), ('style_4', 'Estilo 4'),
         ('style_5', 'Estilo 5'),('style_6', 'Estilo 6'),('style_7', 'Estilo 7')],
        string='Estilo de Plantilla', default='style_1')
    box_per_row = fields.Selection([('2', '2 cajas'), ('3', '3 cajas'), ('4', '4 cajas')], string='Cuadro por fila',
                                   default='2')
    send_catalogue = fields.Boolean(string='Enviar Catalogo')
    partner_ids = fields.Many2many('res.partner', string='Clientes', domain="['|', ('company_id', '=', False), ('company_id', '=', company_id)]")
    template_id = fields.Many2one("mail.template", string='Cargar Plantilla', domain="[('model_id', '=', 'leap.product.catalogue')]")
    # Header and footer fields
    catalogue_header = fields.Binary(string="Pagina de Encabezado", help="Please upload the PDF with the header pages to be printed before the product catalog")
    catalogue_header_name = fields.Char()
    catalogue_footer = fields.Binary(string="Pie de Pagina", help="Please upload the PDF with the footer pages to be printed after the product catalog")
    catalogue_footer_name = fields.Char()

    
    items_pagina= fields.Integer(string="No. de Paginas")
    catalogue_stock = fields.Selection([('active', 'Activado'), ('desactive', 'Desactivado')], string='En existencia',
                                    default='active')

    
    filtrar_fecha = fields.Boolean(string='Filtrar Fecha')

   
    def _get_categoria_producto_options(self):
        categoria_field = self.env['product.template'].fields_get(allfields=['x_studio_antigedad'])['x_studio_antigedad']
        return categoria_field['selection']



    def obtener_productos_fecha(self, products):
        if not self.filtrar_fecha or not self.fecha_inicio or not self.fecha_fin:
            return products
        domain_moves = [
            ('date', '>=', self.fecha_inicio),
            ('date', '<=', self.fecha_fin), 
            ('state', '=', 'done')
        ]
        move_lines = self.env['stock.move.line'].search(domain_moves)
        product_ids = move_lines.mapped('product_id').ids
        filtered = self.env['product.product'].browse(product_ids) & products
        return filtered


    @api.model
    def default_get(self, fields_list):
        defaults = super().default_get(fields_list)
        if 'template_id' in fields_list:
            template = self.env['mail.template'].search(
                [('model_id', '=', 'leap.product.catalogue')], limit=1)
            if template:
                defaults['template_id'] = template.id
        return defaults

    def get_categories(self):
        categories = self.category_ids
        if not categories:
            categories = self.env['product.category'].sudo().search([])
        return categories

    def get_all_product(self):

        products = self.env['product.product'].sudo()

        if  self.antiguedad and (not self.product_ids)and (not self.category_ids) and (not self.marca_ids):
            products = self.env['product.product'].sudo().search(
                            ['|', ('company_id', '=', False), ('company_id', '=', self.company_id.id)
                         ,('x_studio_antigedad','=', self.antiguedad)], order='categ_id, name')


        if self.product_ids:
            if self.product_ids:

                products = self.env['product.product'].sudo().browse(self.product_ids.ids)
                products = products.sorted(key=lambda p: (p.categ_id.name or '', p.name or ''))

            else:
                products = self.env['product.product'].sudo().search(
                    ['|', ('company_id', '=', False), ('company_id', '=', self.company_id.id)],
                    order='categ_id, name')
                
        if (self.category_ids or self.marca_ids) and not self.product_ids:
             
            if self.marca_ids and self.category_ids:
                categories = self.get_categories()
                marcas = self.get_marcas()

                if self.antiguedad:
                    products = self.env['product.product'].sudo().search(
                            ['|', ('company_id', '=', False), ('company_id', '=', self.company_id.id),
                            ('categ_id', 'in', categories.ids),('x_studio_marca', 'in', marcas.ids),('x_studio_antigedad','=', self.antiguedad)],
                            order='categ_id, name')
                else:
                    products = self.env['product.product'].sudo().search(
                            ['|', ('company_id', '=', False), ('company_id', '=', self.company_id.id),
                            ('categ_id', 'in', categories.ids),('x_studio_marca', 'in', marcas.ids)],
                            order='categ_id, name')

            if self.category_ids and not self.marca_ids:

                categories = self.get_categories()

                if self.antiguedad:
                    products = self.env['product.product'].sudo().search(
                        ['|', ('company_id', '=', False), ('company_id', '=', self.company_id.id),
                        ('categ_id', 'in', categories.ids),('x_studio_antigedad','=',self.antiguedad)], order='categ_id, name')
                else:
                         products = self.env['product.product'].sudo().search(
                        ['|', ('company_id', '=', False), ('company_id', '=', self.company_id.id),
                        ('categ_id', 'in', categories.ids)], order='categ_id, name')

            if not self.category_ids and self.marca_ids:
                 
                 marcas = self.get_marcas()
                 if self.antiguedad:
                    products = self.env['product.product'].sudo().search(
                        ['|', ('company_id', '=', False), ('company_id', '=', self.company_id.id),
                    ('x_studio_marca', 'in', marcas.ids),('x_studio_antigedad','=', self.antiguedad)],
                    order='categ_id, name')
                 else:
                    products = self.env['product.product'].sudo().search(
                        ['|', ('company_id', '=', False), ('company_id', '=', self.company_id.id),
                    ('x_studio_marca', 'in', marcas.ids)],
                    order='categ_id, name')
        
            

        # Excluir productos bloqueados
        if self.exclude_product_ids:
            excluded_ids = set(self.exclude_product_ids.ids)
            products = products.filtered(lambda p: p.id not in excluded_ids)

        if self.catalogue_stock =='active':
            products = products.filtered(lambda p : p.qty_available>0)
        
        if self.warehouse_ids:
            ctx = {'warehouse': self.warehouse_ids.ids}
            products = products.with_context(**ctx).search([
                ('id', 'in', products.ids),
                ('qty_available', '>', 0)
            ])

        if not products:
            raise ValidationError(_("No Products Found!"))

        if self.filtrar_fecha:
            products = self.obtener_productos_fecha(products)
        
        # Ordenar: primero por marca del producto (x_studio_marca), luego por categoría propia del producto, luego por nombre
        def sort_key(p):
            try:
                marca = p.x_studio_marca
                marca_name = (marca.name or '').lower() if marca else ''
                sin_marca = not bool(marca)
            except Exception:
                marca_name = ''
                sin_marca = True
            categ_name = (p.categ_id.complete_name or '').lower()
            product_name = (p.name or '').lower()
            return (sin_marca, marca_name, categ_name, product_name)

        products = products.sorted(key=sort_key)
        return products


    @api.constrains('catalogue_type', 'category_ids', 'product_ids')
    def check_all_product(self):
        for record in self:
            record.get_all_product()

    @api.onchange('catalogue_style', 'show_price')
    def onchange_catalogue_styles(self):
        for record in self:
            if record.catalogue_style in ('style_3', 'style_5'):
                record.show_image = True

    @api.onchange('company_id')
    def onchange_company_id(self):
        for record in self:
            record.product_ids = False
            record.pricelist_id = False
            record.partner_ids = False

    def get_product_image(self, product):
        return product.image_128

    def get_product_unit_price(self, product):
        self.ensure_one()
        today_date = fields.Date.today()
        uom = product.uom_id

        # Sin lista de precios: devolver precio base
        if not self.pricelist_id:
            pricelist_rule = self.env['product.pricelist.item'].sudo()
            price = pricelist_rule._compute_price(product, 1.0, uom, today_date, currency=self.currency_id)
            return price

        pricelist = self.pricelist_id

        # Buscar TODAS las reglas de la lista vigentes a la fecha
        domain_rules = [
            ('pricelist_id', '=', pricelist.id),
            '|', ('date_start', '=', False), ('date_start', '<=', today_date),
            '|', ('date_end', '=', False), ('date_end', '>=', today_date),
        ]
        all_rules = self.env['product.pricelist.item'].sudo().search(domain_rules)

        # Filtrar las que apliquen a este producto especificamente
        def rule_applies(rule):
            if rule.product_id and rule.product_id.id != product.id:
                return False
            if rule.product_tmpl_id and rule.product_tmpl_id.id != product.product_tmpl_id.id:
                return False
            if rule.categ_id:
                categ = product.categ_id
                while categ:
                    if categ.id == rule.categ_id.id:
                        return True
                    categ = categ.parent_id
                return False
            return True

        applicable_rules = all_rules.filtered(rule_applies)

        if not applicable_rules:
            rule_id = pricelist._get_product_rule(product, 1.0, uom=uom, date=today_date)
            rule = self.env['product.pricelist.item'].sudo().browse(rule_id)
            return rule._compute_price(product, 1.0, uom, today_date, currency=self.currency_id)

        # Calcular precio para cada regla y retornar el precio mas bajo encontrado
        lowest_price = None
        for rule in applicable_rules:
            qty = rule.min_quantity if rule.min_quantity and rule.min_quantity > 0 else 1.0
            try:
                price_candidate = rule._compute_price(product, qty, uom, today_date, currency=self.currency_id)
                if price_candidate and price_candidate > 0:
                    if lowest_price is None or price_candidate < lowest_price:
                        lowest_price = price_candidate
            except Exception:
                continue

        if lowest_price is None:
            rule_id = pricelist._get_product_rule(product, 1.0, uom=uom, date=today_date)
            rule = self.env['product.pricelist.item'].sudo().browse(rule_id)
            lowest_price = rule._compute_price(product, 1.0, uom, today_date, currency=self.currency_id)

        return lowest_price

    def get_data(self):
        all_products = self.get_all_product()
        
        product_info_list = []
        for index, product in enumerate(all_products.sudo()):
            product_values = {
                'sr_no': index + 1,
                'name': product.display_name,
            }

            if self.show_image:
                product_image = self.get_product_image(product)
                product_values.update({'image': product_image})

            if self.show_internal_reference:
                product_values.update({'internal_reference': product.default_code, })

            if self.show_category:
                product_values.update({'category': product.categ_id.name if self.catalogue_style in (
                    'style_1', 'style_4', 'style_5') else product.categ_id.display_name})

            if self.show_uom:
                product_values.update({'uom': product.uom_id.name})

            if self.show_product_link and product.website_url:
                try:
                    url = request.env['ir.config_parameter'].sudo().get_param('web.base.url') + product.website_url
                except Exception as url_error:
                    raise ValidationError(_(url_error))
                product_values.update({'product_url': url})

            if self.show_price:
                product_price = self.get_product_unit_price(product)
                product_values.update({'product_price': product_price})

            if self.show_description:
                field_name = str(self.description_fields.name) if self.description_fields and self.description_fields.name else ''
                description_value = getattr(product, field_name, '')
                product_values.update({'description': description_value})

            product_info_list.append(product_values)
        return product_info_list

    def create_catalogue(self):
        try:
            pdf = request.env['ir.actions.report'].sudo()._render_qweb_pdf('l4l_product_catalogue.l4l_action_report_product_catalogue', self.ids)[0]
            b64_pdf = base64.b64encode(pdf)
            
            catalogue_id = self.env['leap.product.catalogue'].sudo().create({
                'name': _(self.name),
                'company_id': self.company_id.id,
                'category_ids': [(6, 0, self.get_categories().ids if self.catalogue_type == 'category' else [])],
            })
            if catalogue_id:
                self.env['ir.attachment'].sudo().create({
                    'name': _(self.name),
                    'type': 'binary',
                    'datas': b64_pdf,
                    'company_id': self.company_id.id,
                    'res_model': 'leap.product.catalogue',
                    'res_id': catalogue_id.id,
                    'mimetype': 'application/octet-stream'
                })
                return catalogue_id
        except OSError as e:
           if e.errno == 28:
              raise ValidationError(_("El servidor no tiene espacio en disco para completar esta acción."))
        except Exception as error_message:
            raise ValidationError(_(error_message))

    def button_print_product_catalogue(self):
        self.get_data()
        self.create_catalogue()
        return self.env.ref('l4l_product_catalogue.l4l_action_report_product_catalogue').report_action(self)

    def button_send_product_catalogue_to_customers(self):
        self.get_data()
        catalogue_id = self.create_catalogue()
        if catalogue_id:
            template = self.template_id
            partner_ids = ', '.join(map(str, self.partner_ids.ids))
            attachments = catalogue_id.get_attachments()
            template.write({'partner_to': partner_ids})
            template.send_mail(catalogue_id.id, force_send=True, email_values={
                        'attachment_ids': [(6, 0, [attachments.id])]})

    def get_marcas(self):
        marcas = self.marca_ids
        if not marcas:
            marcas = self.env['product.x_studio_marca'].sudo().search([])
        return marcas



# vim:expandtab:smartcd indent:tabstop=4:softtabstop=4:shiftwidth=4: