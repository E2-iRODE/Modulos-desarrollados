# -*- coding: utf-8 -*-
#
#    OpenERP, Open Source Management Solution
#    Copyright (C) 2023 Leap4Logic Solutions PVT LTD
#    Email : sales@leap4logic.com
#################################################

{
    'name': "Generacion de Catalogos",
    'category': 'Extra Tools',
    'version': '17.0.1.0',
    'sequence': 1,
    'summary': "Generacion de Catalogos",
    
    'depends': ['mail', 'account', 'product', 'sale_management', 'website_sale', 'website'],
    'data': [
        
        'security/res_groups.xml',
        'security/security.xml',
        'security/ir.model.access.csv',
        'data/mail_templates.xml',
        
        'report/catalogue_style_1.xml',
        'report/catalogue_style_2.xml',
        'report/catalogue_style_3.xml',
        'report/catalogue_style_4.xml',
        'report/catalogue_style_5.xml',
        'report/test_4.xml',
        'report/test_2.xml',
        'report/test_3.xml',
        'report/test.xml',
        'report/report_product_catalogue.xml',
        'wizard/generate_product_catalogue_wizard_view.xml',
        'views/main_menu_view.xml',
        'views/leap_product_catalogue_view.xml',
        'views/attachments_extend_views.xml',
        
        
        
    ],
    'application': True,
    'installation': True,
    'license': 'OPL-1',
    
}

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
