{
    "name": "Catalogo Inventario",
    "version": "17.0.1.0.4",
    "summary": "Catálogo de productos con stock por bodega y listas de precios.",
    "description": """
    Stock Catalog View

    Permite consultar, desde el catálogo de productos, las existencias por bodega
    y los precios por lista.
    """,
    "author": "IRODE TECHNOLOGY",
    "website": "https://www.irodetech.com",
    "license": "LGPL-3",
    "category": "Sales/Inventory",
    "depends": [
        "base",
        "product",
        "sale_management",
        "stock",
    ],
    "data": [
        "security/ir.model.access.csv",
        "views/kanba_product.xml"
    ],
   
    "application": True,
    "installable": True,
}