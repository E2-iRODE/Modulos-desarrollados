from odoo import api, fields, models


class ProductTemplate(models.Model):
    _inherit = "product.template"

    @api.model
    def _get_internal_locations_domain(self):
        return [
            "&",
            ("usage", "=", "internal"),
            "|",
            "|",
            "|",
            "|",
            "|",
            ("complete_name", "ilike", "COAT"),
            ("complete_name", "ilike", "IMPO"),
            ("complete_name", "ilike", "VINU"),
            ("complete_name", "ilike", "Xela"),
            ("complete_name", "ilike", "Z11"),
            ("complete_name", "ilike", "Z4"),
        ]

    def _get_stock_by_location(self):
        self.ensure_one()
        product_ids = self.product_variant_ids.ids
        if not product_ids:
            return []
        locations = self.env["stock.location"].search(self._get_internal_locations_domain())
        if not locations:
            return []
        domain = [
            ("product_id", "in", product_ids),
            ("location_id", "in", locations.ids),
        ]
        quants = self.env["stock.quant"].read_group(
            domain,
            ["location_id", "quantity:sum", "available_quantity:sum"],
            ["location_id"],
        )
        result = []
        for q in quants:
            if not q.get("location_id"):
                continue
            loc_id, loc_name = q["location_id"]
            result.append(
                {
                    "location_id": loc_id,
                    "location_name": loc_name,
                    "qty_on_hand": q.get("quantity", 0.0),
                    "qty_available": q.get("available_quantity", 0.0),
                }
            )
        return result

    def _get_pricelist_candidate_qty(self, pricelist, product, date):
        Item = self.env["product.pricelist.item"]
        categ = product.categ_id

        domain = [
            ("pricelist_id", "=", pricelist.id),
            "|",
            ("company_id", "=", False),
            ("company_id", "=", self.env.company.id),
            "|",
            ("date_start", "=", False),
            ("date_start", "<=", date),
            "|",
            ("date_end", "=", False),
            ("date_end", ">=", date),
            "|",
            ("product_id", "=", product.id),
            "|",
            ("product_tmpl_id", "=", product.product_tmpl_id.id),
            "|",
            "&",
            ("categ_id", "!=", False),
            ("categ_id", "parent_of", categ.id),
            ("applied_on", "=", "3_global"),
        ]

        item = Item.search(domain, order="min_quantity asc, id asc", limit=1)
        if not item:
            return 1.0
        return float(item.min_quantity or 1.0)

    def _compute_pricelist_price(self, pricelist, product, qty, partner, date, uom):
        ctx = dict(self.env.context, date=date, uom=uom.id)
        rule_map = pricelist.with_context(ctx)._compute_price_rule(product, qty, partner)
        if not rule_map or product.id not in rule_map:
            return None, None
        price, rule_id = rule_map[product.id]
        return price, rule_id

    def _get_prices_by_pricelist(self, pricelist_ids=None):
        self.ensure_one()
        product = self.product_variant_id
        if not product:
            return []

        Pricelist = self.env["product.pricelist"]
        pricelists = Pricelist.browse(pricelist_ids) if pricelist_ids else Pricelist.search([("active", "=", True)])

        partner = self.env["res.partner"]
        date = fields.Date.context_today(self)
        uom = product.uom_id

        result = []
        for plist in pricelists:
            if "garant" in (plist.name or "").lower():
                continue

            price, rule_id = self._compute_pricelist_price(plist, product, 1.0, partner, date, uom)

            if not rule_id:
                qty = self._get_pricelist_candidate_qty(plist, product, date)
                price, rule_id = self._compute_pricelist_price(plist, product, qty, partner, date, uom)

            if not rule_id or price is None:
                continue

            price = plist.currency_id.round(price)

            result.append(
                {
                    "pricelist_id": plist.id,
                    "pricelist_name": plist.name,
                    "price": price,
                    "currency": plist.currency_id.symbol,
                    "error": None,
                }
            )
        return result

    @api.model
    def get_stock_and_prices(self, product_tmpl_id, pricelist_ids=None):
        product_tmpl = self.browse(product_tmpl_id)
        if not product_tmpl.exists():
            return {}
        sku_name = ""
        sku = getattr(product_tmpl, "x_studio_ubicaciones_sku", False)
        if sku:
            sku_name = sku.display_name or ""
        return {
            "product_tmpl_id": product_tmpl.id,
            "name": product_tmpl.display_name,
            "sku_name": sku_name,
            "stock_by_location": product_tmpl._get_stock_by_location(),
            "prices": product_tmpl._get_prices_by_pricelist(pricelist_ids),
        }

    def action_view_stock_by_location(self):
        self.ensure_one()
        action = self.env.ref("stock.stock_quants_action").read()[0]
        product_ids = self.product_variant_ids.ids
        action["domain"] = [("product_id", "in", product_ids)]
        ctx = dict(self.env.context)
        if product_ids:
            ctx["default_product_id"] = product_ids[0]
        action["context"] = ctx
        return action

    def action_view_pricelist_items(self):
        self.ensure_one()
        action = self.env.ref("product.product_pricelist_item_action").read()[0]
        action["domain"] = [
            "|",
            ("product_tmpl_id", "=", self.id),
            ("product_id", "in", self.product_variant_ids.ids),
        ]
        ctx = dict(self.env.context)
        ctx["default_product_tmpl_id"] = self.id
        action["context"] = ctx
        return action


class ProductProduct(models.Model):
    _inherit = "product.product"

    sku_display = fields.Char(compute="_compute_sku_display", string="SKU")
    stock_locations_display = fields.Char(compute="_compute_stock_locations_display", string="Stock por bodega")
    prices_display = fields.Char(compute="_compute_prices_display", string="Precios por lista")

    def _compute_sku_display(self):
        for product in self:
            tmpl = product.product_tmpl_id
            sku = getattr(tmpl, "x_studio_ubicaciones_sku", False) if tmpl else False
            product.sku_display = sku.display_name if sku else ""

    def _compute_stock_locations_display(self):
        for product in self:
            tmpl = product.product_tmpl_id
            if not tmpl:
                product.stock_locations_display = ""
                continue
            data = tmpl._get_stock_by_location()
            if not data:
                product.stock_locations_display = ""
                continue
            parts = []
            for item in data:
                loc_name = item["location_name"]
                qty_on = item.get("qty_on_hand") or 0.0
                qty_av = item.get("qty_available") or 0.0
                parts.append(f"{loc_name}: {qty_on:.2f}/{qty_av:.2f}")
            product.stock_locations_display = " | ".join(parts)

    def _compute_prices_display(self):
        for product in self:
            tmpl = product.product_tmpl_id
            if not tmpl:
                product.prices_display = ""
                continue
            data = tmpl._get_prices_by_pricelist()
            if not data:
                product.prices_display = ""
                continue
            parts = []
            for item in data:
                name = item.get("pricelist_name") or ""
                currency = item.get("currency") or ""
                price = item.get("price")
                if price is None:
                    parts.append(f"{name}: {currency}N/A")
                else:
                    parts.append(f"{name}: {currency}{price:.2f}")
            product.prices_display = " | ".join(parts)
