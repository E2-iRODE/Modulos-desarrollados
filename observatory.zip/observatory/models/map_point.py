from odoo import api, fields, models


class WebsiteMapPointTag(models.Model):
    _name = "website.map.point.tag"
    _description = "Map Point Tag"
    _order = "name"

    name = fields.Char(required=True)
    color = fields.Integer(default=0)


class WebsiteMapPoint(models.Model):
    _name = "website.map.point"
    _description = "Website Map Point"
    _order = "id"

    website_published = fields.Boolean(default=True)

    name = fields.Char(required=True)
    project_id = fields.Many2one("project.project", ondelete="set null")
    description = fields.Text()
    link = fields.Char(string="Enlace del proyecto")

    state = fields.Selection([
        ("planning", "Planificación"),
        ("active", "Activo"),
        ("in_progress", "En Progreso"),
        ("completed", "Completado"),
        ("on_hold", "En Espera"),
    ], default="planning", required=True, string="Estado")

    phone = fields.Char(string="Teléfono")
    email = fields.Char(string="Correo electrónico")
    responsible_id = fields.Many2one("res.users", string="Responsable", ondelete="set null")

    image = fields.Binary(string="Imagen", attachment=True)

    tag_ids = fields.Many2many("website.map.point.tag", string="Etiquetas")

    street = fields.Char()
    street2 = fields.Char()
    city = fields.Char()
    state_id = fields.Many2one("res.country.state", ondelete="restrict")
    zip = fields.Char()
    country_id = fields.Many2one("res.country", ondelete="restrict")

    latitude = fields.Float(digits=(16, 7))
    longitude = fields.Float(digits=(16, 7))

    category = fields.Selection([
        ("default", "Default"),
        ("project", "Project"),
        ("tower", "Tower"),
    ], default="project", required=True)

    address_display = fields.Char(compute="_compute_address_display", store=True)

    @api.depends("street", "street2", "city", "state_id", "zip", "country_id")
    def _compute_address_display(self):
        for rec in self:
            parts = []
            if rec.street:
                parts.append(rec.street)
            if rec.street2:
                parts.append(rec.street2)
            line2 = []
            if rec.zip:
                line2.append(rec.zip)
            if rec.city:
                line2.append(rec.city)
            if rec.state_id:
                line2.append(rec.state_id.name)
            if line2:
                parts.append(" ".join(line2))
            if rec.country_id:
                parts.append(rec.country_id.name)
            rec.address_display = ", ".join([p for p in parts if p])