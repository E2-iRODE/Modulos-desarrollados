{
    "name": "Observatorio",
    "version": "18.0.1.0.0",
    "category": "Website",
    "summary": "Aplicación para administrar puntos y visualizarlos en /mapa",
    "depends": ["website", "project"],
    "data": [
        "security/ir.model.access.csv",
        "views/backend_menu.xml",
        "views/map_point_views.xml",
        "views/website_menu.xml",
        "views/templates.xml",
    ],
    "assets": {
        "web.assets_frontend": [
            "website_map_view/static/src/css/website_map_view.css",
            "website_map_view/static/src/js/website_map_view.js",
        ],
    },
    "installable": True,
    "application": True,
    "license": "LGPL-3",
}