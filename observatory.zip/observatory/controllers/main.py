import json
from odoo import http
from odoo.http import request


class WebsiteMapViewController(http.Controller):
    @http.route("/mapa", type="http", auth="public", website=True, sitemap=True)
    def website_map(self, **kwargs):
        return request.render("website_map_view.page_map", {})

    @http.route("/mapa/data", type="http", auth="public", website=True, sitemap=False, methods=["GET"])
    def website_map_data(self, **kwargs):
        points = request.env["website.map.point"].sudo().search([
            ("website_published", "=", True),
            ("latitude", "!=", False),
            ("longitude", "!=", False),
        ])
        is_internal = request.env.user.has_group('base.group_user')

        data = []

        for p in points:
            image_src = ""
            if p.image:
                image_src = "data:image/png;base64,%s" % p.image.decode("utf-8") if isinstance(p.image, bytes) else "data:image/png;base64,%s" % p.image

            tags = [{"name": t.name, "color": t.color} for t in p.tag_ids]

            data.append({
                "id": p.id,
                "name": p.name,
                "project_name": p.project_id.display_name if p.project_id else "",
                "project_id": p.project_id.id if p.project_id else "",
                "lat": float(p.latitude),
                "lng": float(p.longitude),
                "address": p.address_display or "",
                "category": p.category or "default",
                "state": p.state or "planning",
                "description": p.description or "",
                "phone": p.phone or "",
                "email": p.email or "",
                "responsible": p.responsible_id.name if p.responsible_id else "",
                "image": image_src,
                "tags": tags,
                "city": p.city or "",
                "country": p.country_id.name if p.country_id else "",
                "link": p.link or "",
            })

        body = json.dumps({"points": data, "is_internal": is_internal})
        return request.make_response(
            body,
            headers=[("Content-Type", "application/json; charset=utf-8")]
        )