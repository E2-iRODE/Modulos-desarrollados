(function () {
  var STATE_LABELS = {
    planning: "Planificación",
    active: "Activo",
    in_progress: "En Progreso",
    completed: "Completado",
    on_hold: "En Espera",
  };

  var CATEGORY_LABELS = {
    default: "Default",
    project: "Proyecto",
    tower: "Torre",
  };

  function loadCss(href) {
    return new Promise(function (resolve, reject) {
      var existing = document.querySelector('link[href="' + href + '"]');
      if (existing) return resolve();
      var link = document.createElement("link");
      link.rel = "stylesheet";
      link.href = href;
      link.onload = function () {
        resolve();
      };
      link.onerror = function () {
        reject(new Error("CSS load failed: " + href));
      };
      document.head.appendChild(link);
    });
  }

  function loadScript(src) {
    return new Promise(function (resolve, reject) {
      var existing = document.querySelector('script[src="' + src + '"]');
      if (existing) return resolve();
      var script = document.createElement("script");
      script.src = src;
      script.async = true;
      script.onload = function () {
        resolve();
      };
      script.onerror = function () {
        reject(new Error("Script load failed: " + src));
      };
      document.head.appendChild(script);
    });
  }

  async function ensureLeaflet() {
    if (window.L) return;
    await loadCss("https://unpkg.com/leaflet@1.9.4/dist/leaflet.css");
    await loadScript("https://unpkg.com/leaflet@1.9.4/dist/leaflet.js");
    if (!window.L) throw new Error("Leaflet not available after load");
  }

  async function fetchPoints() {
    var res = await fetch("/mapa/data", {
      method: "GET",
      credentials: "same-origin",
    });

    if (!res.ok) return { points: [], is_internal: false };

    var payload = await res.json();

    return {
      points: Array.isArray(payload.points) ? payload.points : [],
      is_internal: payload.is_internal || false,
    };
  }

  function esc(s) {
    var div = document.createElement("div");
    div.appendChild(document.createTextNode(String(s || "")));
    return div.innerHTML;
  }

  function svgIcon(type) {
    var icons = {
      pin: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>',
      link: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/></svg>',
      phone:
        '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.127.96.361 1.903.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0 1 22 16.92z"/></svg>',
      mail: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>',
      user: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>',
      globe:
        '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg>',
      mapPlaceholder:
        '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>',
    };
    return icons[type] || "";
  }

  function buildRow(icon, label, valueHTML) {
    return (
      '<div class="irode-panel-row">' +
      '<div class="irode-panel-row-icon">' +
      svgIcon(icon) +
      "</div>" +
      '<div class="irode-panel-row-content">' +
      '<div class="irode-panel-row-label">' +
      label +
      "</div>" +
      '<div class="irode-panel-row-value">' +
      valueHTML +
      "</div>" +
      "</div></div>"
    );
  }

  function buildPanelHTML(p, is_internal) {
    if (typeof is_internal === "undefined") {
      is_internal = false;
    }
    var heroHTML;
    if (p.image) {
      heroHTML =
        '<div class="irode-panel-hero"><img src="' +
        esc(p.image) +
        '" alt="' +
        esc(p.name) +
        '"/><div class="irode-panel-hero-gradient"></div></div>';
    } else {
      heroHTML =
        '<div class="irode-panel-hero"><div class="irode-panel-hero-placeholder">' +
        svgIcon("mapPlaceholder") +
        '</div><div class="irode-panel-hero-gradient"></div></div>';
    }

    var badgesHTML = '<div class="irode-panel-badges">';
    if (p.state && STATE_LABELS[p.state]) {
      badgesHTML +=
        '<span class="irode-badge irode-badge-state-' +
        esc(p.state) +
        '"><span class="irode-badge-dot"></span>' +
        esc(STATE_LABELS[p.state]) +
        "</span>";
    }
    if (p.category && CATEGORY_LABELS[p.category]) {
      badgesHTML +=
        '<span class="irode-badge irode-badge-category">' +
        esc(CATEGORY_LABELS[p.category]) +
        "</span>";
    }
    badgesHTML += "</div>";

    var titleHTML = '<h2 class="irode-panel-title">' + esc(p.name) + "</h2>";
    var projectHTML = p.project_name
      ? '<div class="irode-panel-project">' + esc(p.project_name) + "</div>"
      : '<div style="margin-bottom:20px"></div>';

    var actionButtonHTML = is_internal
      ? '<button class="irode-panel-action-button" type="button" data-project-id="' +
        p.project_id +
        '">Ver Detalles Completos</button>'
      : "";

    var infoRows = "";

    if (p.address) {
      infoRows += buildRow("pin", "Dirección", esc(p.address));
    } else {
      var location = [p.city, p.country].filter(Boolean).join(", ");
      if (location) {
        infoRows += buildRow("pin", "Ubicación", esc(location));
      }
    }

    if (p.link) {
      infoRows += buildRow(
        "link",
        "Conoce más sobre el impacto de este proyecto",
        '<a href="' +
          esc(p.link) +
          '" target="_blank" rel="noopener noreferrer">Ver proyecto</a>',
      );
    }

    if (p.responsible) {
      infoRows += buildRow("user", "Responsable", esc(p.responsible));
    }

    if (p.phone) {
      infoRows += buildRow(
        "phone",
        "Teléfono",
        '<a href="tel:' + esc(p.phone) + '">' + esc(p.phone) + "</a>",
      );
    }

    if (p.email) {
      infoRows += buildRow(
        "mail",
        "Correo",
        '<a href="mailto:' + esc(p.email) + '">' + esc(p.email) + "</a>",
      );
    }

    var coordsHTML = buildRow(
      "globe",
      "Coordenadas",
      esc(p.lat.toFixed(6) + ", " + p.lng.toFixed(6)),
    );

    var infoSection =
      '<div class="irode-panel-section"><div class="irode-panel-section-title">Información</div>' +
      infoRows +
      coordsHTML +
      "</div>";

    var descSection = "";
    if (p.description) {
      descSection =
        '<div class="irode-panel-section"><div class="irode-panel-section-title">Descripción</div><div class="irode-panel-description">' +
        esc(p.description).replace(/\n/g, "<br/>") +
        "</div></div>";
    }

    var tagsSection = "";
    if (p.tags && p.tags.length > 0) {
      var tagsInner = p.tags
        .map(function (t) {
          return '<span class="irode-panel-tag">' + esc(t.name) + "</span>";
        })
        .join("");
      tagsSection =
        '<div class="irode-panel-section"><div class="irode-panel-section-title">Etiquetas</div><div class="irode-panel-tags">' +
        tagsInner +
        "</div></div>";
    }

    return (
      heroHTML +
      '<div class="irode-panel-body">' +
      badgesHTML +
      titleHTML +
      projectHTML +
      actionButtonHTML +
      infoSection +
      descSection +
      tagsSection +
      "</div>"
    );
  }

  function openPanel(p) {
    var wrapper = document.querySelector(".irode-map-wrapper");
    var content = document.getElementById("irode_panel_content");
    if (!wrapper || !content) return;
    content.innerHTML = buildPanelHTML(p, window._isInternal);

    var btn = content.querySelector(".irode-panel-action-button");
    if (btn) {
      btn.addEventListener("click", function () {
        var pid = btn.getAttribute("data-project-id");
        if (pid) {
          window.top.location.href = "/my/projects/" + pid;
        }
      });
    }
    wrapper.classList.add("panel-open");
    setTimeout(function () {
      if (window._irodeMap) window._irodeMap.invalidateSize();
    }, 450);
  }

  function closePanel() {
    var wrapper = document.querySelector(".irode-map-wrapper");
    if (!wrapper) return;
    wrapper.classList.remove("panel-open");
    setTimeout(function () {
      if (window._irodeMap) window._irodeMap.invalidateSize();
    }, 450);
  }

  function initMap(points) {
    var el = document.getElementById("irode_map");
    if (!el) return;

    var statusEl = document.getElementById("irode_map_status");
    var closeBtn = document.getElementById("irode_panel_close");

    if (closeBtn) {
      closeBtn.addEventListener("click", function (e) {
        e.preventDefault();
        e.stopPropagation();
        closePanel();
      });
    }

    var map = window.L.map(el, { scrollWheelZoom: true }).setView(
      [15.7835, -90.2308],
      7,
    );
    window._irodeMap = map;

    window.L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
      maxZoom: 19,
      attribution: "&copy; OpenStreetMap",
    }).addTo(map);

    var bounds = [];

    for (var i = 0; i < points.length; i++) {
      (function (p) {
        var lat = Number(p.lat);
        var lng = Number(p.lng);
        if (!Number.isFinite(lat) || !Number.isFinite(lng)) return;

        var marker = window.L.marker([lat, lng]);
        marker.addTo(map);
        marker.on("click", function () {
          openPanel(p);
        });

        bounds.push([lat, lng]);
      })(points[i]);
    }

    if (bounds.length) {
      map.fitBounds(bounds, { padding: [24, 24] });
      if (statusEl) statusEl.textContent = bounds.length + " puntos";
    } else {
      if (statusEl) statusEl.textContent = "Sin puntos publicados";
    }
  }

  async function boot() {
    var el = document.getElementById("irode_map");
    if (!el) return;
    await ensureLeaflet();
    var data = await fetchPoints();
    window._isInternal = data.is_internal;
    initMap(data.points);
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", function () {
      boot().catch(function () {});
    });
  } else {
    boot().catch(function () {});
  }
})();
